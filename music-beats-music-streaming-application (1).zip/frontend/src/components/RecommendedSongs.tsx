import { useMusicPlayer } from '../contexts/MusicPlayerContext';
import { useRateSong, useAddToListeningHistory } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Play, Star, ListPlus } from 'lucide-react';
import { useState } from 'react';
import SongRatingDialog from './SongRatingDialog';
import AddToPlaylistDialog from './AddToPlaylistDialog';
import type { YTMusicSong } from '../backend';

export default function RecommendedSongs() {
  const { playSong } = useMusicPlayer();
  const { identity } = useInternetIdentity();
  const addToHistory = useAddToListeningHistory();
  const [ratingDialogOpen, setRatingDialogOpen] = useState(false);
  const [playlistDialogOpen, setPlaylistDialogOpen] = useState(false);
  const [selectedSong, setSelectedSong] = useState<YTMusicSong | null>(null);

  // Fallback hardcoded songs
  const fallbackSongs: YTMusicSong[] = [
    {
      id: '1',
      title: 'Shape of You',
      artist: 'Ed Sheeran',
      album: 'Divide',
      genre: 'Pop',
      duration: BigInt(234),
      youtubeId: 'JGwWNGJdvx8',
      coverImage: 'https://i.ytimg.com/vi/JGwWNGJdvx8/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '2',
      title: 'Blinding Lights',
      artist: 'The Weeknd',
      album: 'After Hours',
      genre: 'Pop',
      duration: BigInt(200),
      youtubeId: '4NRXx6U8ABQ',
      coverImage: 'https://i.ytimg.com/vi/4NRXx6U8ABQ/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '3',
      title: 'Tum Hi Ho',
      artist: 'Arijit Singh',
      album: 'Aashiqui 2',
      genre: 'Hindi',
      duration: BigInt(262),
      youtubeId: 'IJq0yyWug1k',
      coverImage: 'https://i.ytimg.com/vi/IJq0yyWug1k/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '4',
      title: 'Kesariya',
      artist: 'Arijit Singh',
      album: 'Brahmastra',
      genre: 'Hindi',
      duration: BigInt(268),
      youtubeId: 'hA6hldpSTF8',
      coverImage: 'https://i.ytimg.com/vi/hA6hldpSTF8/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '5',
      title: 'Levitating',
      artist: 'Dua Lipa',
      album: 'Future Nostalgia',
      genre: 'Pop',
      duration: BigInt(203),
      youtubeId: 'TUVcZfQe-Kw',
      coverImage: 'https://i.ytimg.com/vi/TUVcZfQe-Kw/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '6',
      title: 'Channa Mereya',
      artist: 'Arijit Singh',
      album: 'Ae Dil Hai Mushkil',
      genre: 'Hindi',
      duration: BigInt(298),
      youtubeId: 'bzSTpdcs-EI',
      coverImage: 'https://i.ytimg.com/vi/bzSTpdcs-EI/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '7',
      title: 'Peaches',
      artist: 'Justin Bieber',
      album: 'Justice',
      genre: 'Pop',
      duration: BigInt(198),
      youtubeId: 'tQ0yjYUFKAE',
      coverImage: 'https://i.ytimg.com/vi/tQ0yjYUFKAE/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '8',
      title: 'Raabta',
      artist: 'Arijit Singh',
      album: 'Agent Vinod',
      genre: 'Hindi',
      duration: BigInt(240),
      youtubeId: 'W3vwGoQIyjs',
      coverImage: 'https://i.ytimg.com/vi/W3vwGoQIyjs/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '9',
      title: 'Stay',
      artist: 'The Kid LAROI & Justin Bieber',
      album: 'Stay',
      genre: 'Pop',
      duration: BigInt(141),
      youtubeId: 'kTJczUoc26U',
      coverImage: 'https://i.ytimg.com/vi/kTJczUoc26U/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '10',
      title: 'Agar Tum Saath Ho',
      artist: 'Alka Yagnik & Arijit Singh',
      album: 'Tamasha',
      genre: 'Hindi',
      duration: BigInt(338),
      youtubeId: 'sK7riqg2mr4',
      coverImage: 'https://i.ytimg.com/vi/sK7riqg2mr4/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '11',
      title: 'Good 4 U',
      artist: 'Olivia Rodrigo',
      album: 'SOUR',
      genre: 'Pop',
      duration: BigInt(178),
      youtubeId: 'gNi_6U5Pm_o',
      coverImage: 'https://i.ytimg.com/vi/gNi_6U5Pm_o/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '12',
      title: 'Kabira',
      artist: 'Tochi Raina & Rekha Bhardwaj',
      album: 'Yeh Jawaani Hai Deewani',
      genre: 'Hindi',
      duration: BigInt(245),
      youtubeId: 'jHNNMj5bNQw',
      coverImage: 'https://i.ytimg.com/vi/jHNNMj5bNQw/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '13',
      title: 'Heat Waves',
      artist: 'Glass Animals',
      album: 'Dreamland',
      genre: 'Pop',
      duration: BigInt(238),
      youtubeId: 'mRD0-GxqHVo',
      coverImage: 'https://i.ytimg.com/vi/mRD0-GxqHVo/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '14',
      title: 'Phir Bhi Tumko Chaahunga',
      artist: 'Arijit Singh',
      album: 'Half Girlfriend',
      genre: 'Hindi',
      duration: BigInt(323),
      youtubeId: 'NVq82bNB7lk',
      coverImage: 'https://i.ytimg.com/vi/NVq82bNB7lk/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '15',
      title: 'As It Was',
      artist: 'Harry Styles',
      album: "Harry's House",
      genre: 'Pop',
      duration: BigInt(167),
      youtubeId: 'H5v3kku4y6Q',
      coverImage: 'https://i.ytimg.com/vi/H5v3kku4y6Q/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '16',
      title: 'Ae Dil Hai Mushkil',
      artist: 'Arijit Singh',
      album: 'Ae Dil Hai Mushkil',
      genre: 'Hindi',
      duration: BigInt(272),
      youtubeId: 'Z_PODraXg4E',
      coverImage: 'https://i.ytimg.com/vi/Z_PODraXg4E/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '17',
      title: 'Anti-Hero',
      artist: 'Taylor Swift',
      album: 'Midnights',
      genre: 'Pop',
      duration: BigInt(200),
      youtubeId: 'b1kbLwvqugk',
      coverImage: 'https://i.ytimg.com/vi/b1kbLwvqugk/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '18',
      title: 'Hawayein',
      artist: 'Arijit Singh',
      album: 'Jab Harry Met Sejal',
      genre: 'Hindi',
      duration: BigInt(227),
      youtubeId: '1wXrN6IDhsM',
      coverImage: 'https://i.ytimg.com/vi/1wXrN6IDhsM/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '19',
      title: 'Flowers',
      artist: 'Miley Cyrus',
      album: 'Endless Summer Vacation',
      genre: 'Pop',
      duration: BigInt(200),
      youtubeId: 'G7KNmW9a75Y',
      coverImage: 'https://i.ytimg.com/vi/G7KNmW9a75Y/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
    {
      id: '20',
      title: 'Pehla Nasha',
      artist: 'Udit Narayan & Sadhana Sargam',
      album: 'Jo Jeeta Wohi Sikandar',
      genre: 'Hindi',
      duration: BigInt(330),
      youtubeId: 'NbxW8PsdhBs',
      coverImage: 'https://i.ytimg.com/vi/NbxW8PsdhBs/maxresdefault.jpg',
      audioPreviewUrl: '',
    },
  ];

  const handlePlaySong = (song: YTMusicSong) => {
    playSong(song, fallbackSongs);
    if (identity) {
      addToHistory.mutate(song.id);
    }
  };

  const handleRateSong = (song: YTMusicSong) => {
    setSelectedSong(song);
    setRatingDialogOpen(true);
  };

  const handleAddToPlaylist = (song: YTMusicSong) => {
    setSelectedSong(song);
    setPlaylistDialogOpen(true);
  };

  const formatDuration = (seconds: bigint) => {
    const mins = Math.floor(Number(seconds) / 60);
    const secs = Number(seconds) % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {fallbackSongs.map((song) => (
          <Card key={song.id} className="overflow-hidden hover:shadow-lg transition-shadow group">
            <div className="relative aspect-square overflow-hidden bg-muted">
              <img src={song.coverImage} alt={song.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Button
                  size="lg"
                  className="rounded-full w-16 h-16 bg-primary hover:bg-primary/90"
                  onClick={() => handlePlaySong(song)}
                >
                  <Play className="h-6 w-6 fill-current" />
                </Button>
              </div>
            </div>
            <CardContent className="p-4">
              <h3 className="font-semibold text-sm mb-1 truncate">{song.title}</h3>
              <p className="text-xs text-muted-foreground mb-2 truncate">{song.artist}</p>
              <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                <span>{song.genre}</span>
                <span>{formatDuration(song.duration)}</span>
              </div>
              {identity && (
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => handleRateSong(song)}
                  >
                    <Star className="h-3 w-3 mr-1" />
                    Rate
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => handleAddToPlaylist(song)}
                  >
                    <ListPlus className="h-3 w-3 mr-1" />
                    Add
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedSong && (
        <>
          <SongRatingDialog
            open={ratingDialogOpen}
            onOpenChange={setRatingDialogOpen}
            song={selectedSong}
          />
          <AddToPlaylistDialog
            open={playlistDialogOpen}
            onOpenChange={setPlaylistDialogOpen}
            song={selectedSong}
          />
        </>
      )}
    </>
  );
}
