import { useGetListeningHistory } from '../hooks/useQueries';
import { Card } from '@/components/ui/card';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Music } from 'lucide-react';

export default function RecentlyPlayed() {
  const { data: history, isLoading } = useGetListeningHistory();

  if (isLoading) {
    return (
      <section className="container px-4">
        <h2 className="text-2xl font-bold mb-6">Recently Played</h2>
        <div className="shimmer h-32 rounded-lg" />
      </section>
    );
  }

  if (!history || history.length === 0) {
    return null;
  }

  return (
    <section className="container px-4">
      <h2 className="text-2xl font-bold mb-6">Recently Played</h2>
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex gap-4 pb-4">
          {history.slice(0, 10).map((entry) => (
            <Card key={entry.timestamp.toString()} className="w-40 flex-shrink-0 p-4 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="aspect-square rounded-md bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center mb-3">
                <Music className="h-8 w-8 text-primary" />
              </div>
              <p className="text-sm font-medium truncate">Song {entry.songId}</p>
              <p className="text-xs text-muted-foreground">Recently played</p>
            </Card>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </section>
  );
}
