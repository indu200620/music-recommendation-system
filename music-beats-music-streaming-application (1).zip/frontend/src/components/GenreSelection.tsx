import { useGetAllGenres, useGetSongsByGenre } from '../hooks/useQueries';
import { useMusicPlayer } from '../contexts/MusicPlayerContext';
import { Card } from '@/components/ui/card';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { useState, useEffect } from 'react';
import type { Genre, YTMusicSong } from '../backend';
import { toast } from 'sonner';

interface GenreSelectionProps {
  onGenreSelect?: (genre: string, songs: YTMusicSong[]) => void;
}

export default function GenreSelection({ onGenreSelect }: GenreSelectionProps) {
  const { data: genres, isLoading } = useGetAllGenres();
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const { playSong } = useMusicPlayer();

  const { data: genreSongs, isLoading: genreSongsLoading, refetch } = useGetSongsByGenre(selectedGenre || '');

  const genreIcons: Record<string, string> = {
    'Pop': '/assets/generated/pop-genre-icon-transparent.dim_64x64.png',
    'Classical': '/assets/generated/classical-genre-icon-transparent.dim_64x64.png',
    'Jazz': '/assets/generated/jazz-genre-icon-transparent.dim_64x64.png',
    'Rock': '/assets/generated/rock-genre-icon-transparent.dim_64x64.png',
    'Hip-Hop': '/assets/generated/hiphop-genre-icon-transparent.dim_64x64.png',
    'English': '/assets/generated/english-genre-icon-transparent.dim_64x64.png',
    'Hindi': '/assets/generated/hindi-genre-icon-transparent.dim_64x64.png',
    'Folk': '/assets/generated/folk-genre-icon-transparent.dim_64x64.png',
    'Instrumental': '/assets/generated/instrumental-genre-icon-transparent.dim_64x64.png',
    'Electronic': '/assets/generated/electronic-genre-icon-transparent.dim_64x64.png',
  };

  useEffect(() => {
    if (selectedGenre && genreSongs && genreSongs.length > 0 && !genreSongsLoading) {
      // Start playback with the first song in the genre list
      playSong(genreSongs[0], genreSongs);
      
      // Notify parent component
      onGenreSelect?.(selectedGenre, genreSongs);
      
      toast.success(`Now playing ${selectedGenre} music`);
    }
  }, [genreSongs, selectedGenre, genreSongsLoading]);

  const handleGenreClick = async (genre: Genre) => {
    setSelectedGenre(genre.name);
  };

  if (isLoading) {
    return (
      <div className="w-full">
        <div className="flex gap-4 overflow-x-auto pb-4">
          {[...Array(8)].map((_, i) => (
            <Skeleton key={i} className="h-32 w-32 flex-shrink-0 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  if (!genres || genres.length === 0) {
    return null;
  }

  return (
    <div className="w-full">
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex gap-4 pb-4">
          {genres.map((genre) => (
            <Card
              key={genre.name}
              onClick={() => handleGenreClick(genre)}
              className={`
                flex-shrink-0 w-32 h-32 cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-lg
                ${selectedGenre === genre.name ? 'ring-2 ring-primary shadow-xl scale-105' : ''}
                ${genreSongsLoading && selectedGenre === genre.name ? 'opacity-50 pointer-events-none' : ''}
              `}
            >
              <div className="h-full flex flex-col items-center justify-center p-4 gap-2">
                <div className="w-12 h-12 flex items-center justify-center">
                  <img
                    src={genreIcons[genre.name] || '/assets/generated/music-note-icon-transparent.dim_64x64.png'}
                    alt={genre.name}
                    className="w-full h-full object-contain"
                  />
                </div>
                <h3 className="text-sm font-semibold text-center">{genre.name}</h3>
              </div>
            </Card>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  );
}
