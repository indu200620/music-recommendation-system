export default function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-secondary/20" />
      <div className="container relative px-4 py-16 md:py-24">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="flex-1 space-y-6 text-center md:text-left">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight">
              Discover the Best of{' '}
              <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">Music</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl">
              Stream unlimited English and Hindi songs, create playlists, and enjoy personalized recommendations powered by your taste.
            </p>
          </div>
          <div className="flex-1">
            <img src="/assets/generated/hero-banner.dim_1200x400.png" alt="Music" className="w-full h-auto rounded-2xl shadow-2xl" />
          </div>
        </div>
      </div>
    </section>
  );
}
