import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Star } from 'lucide-react';
import { useRateSong } from '../hooks/useQueries';
import type { YTMusicSong } from '../backend';

interface SongRatingDialogProps {
  song: YTMusicSong;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function SongRatingDialog({ song, open, onOpenChange }: SongRatingDialogProps) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const rateSong = useRateSong();

  const handleSubmit = async () => {
    if (rating === 0) return;
    await rateSong.mutateAsync({ songId: song.id, rating });
    onOpenChange(false);
    setRating(0);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Rate Song</DialogTitle>
          <DialogDescription>
            How would you rate "{song.title}" by {song.artist}?
          </DialogDescription>
        </DialogHeader>
        <div className="flex justify-center gap-2 py-6">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => setRating(star)}
              onMouseEnter={() => setHoveredRating(star)}
              onMouseLeave={() => setHoveredRating(0)}
              className="transition-transform hover:scale-110"
            >
              <Star
                className={`h-10 w-10 ${
                  star <= (hoveredRating || rating) ? 'fill-secondary text-secondary' : 'text-muted-foreground'
                }`}
              />
            </button>
          ))}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={rating === 0 || rateSong.isPending}>
            {rateSong.isPending ? 'Submitting...' : 'Submit Rating'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
