import { useMusicPlayer } from '../contexts/MusicPlayerContext';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Play, Pause, SkipBack, SkipForward, Repeat, Shuffle, Volume2, VolumeX, Loader2, AlertCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function AudioPlayer() {
  const {
    currentSong,
    isPlaying,
    volume,
    currentTime,
    duration,
    isRepeat,
    isShuffle,
    isLoading,
    error,
    pauseSong,
    resumeSong,
    nextSong,
    previousSong,
    setVolume,
    seekTo,
    toggleRepeat,
    toggleShuffle,
  } = useMusicPlayer();

  const [isMuted, setIsMuted] = useState(false);
  const [previousVolume, setPreviousVolume] = useState(volume);
  const [showError, setShowError] = useState(false);

  useEffect(() => {
    if (error) {
      setShowError(true);
      const timer = setTimeout(() => {
        setShowError(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  if (!currentSong) return null;

  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || !isFinite(seconds) || seconds < 0) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleVolumeToggle = () => {
    if (isMuted || volume === 0) {
      setVolume(previousVolume > 0 ? previousVolume : 70);
      setIsMuted(false);
    } else {
      setPreviousVolume(volume);
      setVolume(0);
      setIsMuted(true);
    }
  };

  const handleProgressChange = (value: number[]) => {
    const newTime = value[0];
    seekTo(newTime);
  };

  const progressValue = isNaN(currentTime) || !isFinite(currentTime) ? 0 : Math.max(0, currentTime);
  const durationValue = isNaN(duration) || !isFinite(duration) || duration <= 0 ? 100 : duration;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 border-t bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      {showError && error && (
        <div className="container px-4 pt-2">
          <Alert variant="destructive" className="py-2 animate-in fade-in slide-in-from-bottom-2">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-sm">{error}</AlertDescription>
          </Alert>
        </div>
      )}

      <div className="container px-4 py-3">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <div className="relative">
              <img
                src={currentSong.coverImage || '/assets/generated/music-note-icon-transparent.dim_64x64.png'}
                alt={currentSong.title}
                className="h-14 w-14 rounded-md object-cover"
              />
              {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-md">
                  <Loader2 className="h-5 w-5 animate-spin text-white" />
                </div>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-medium truncate">{currentSong.title}</p>
              <p className="text-sm text-muted-foreground truncate">{currentSong.artist}</p>
            </div>
          </div>

          <div className="flex flex-col items-center gap-2 flex-1 max-w-2xl">
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleShuffle}
                className={isShuffle ? 'text-secondary' : ''}
                title={isShuffle ? 'Shuffle on' : 'Shuffle off'}
              >
                <Shuffle className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" onClick={previousSong} disabled={isLoading} title="Previous song">
                <SkipBack className="h-5 w-5" />
              </Button>
              <Button
                size="icon"
                className="h-10 w-10 rounded-full bg-primary hover:bg-primary/90"
                onClick={isPlaying ? pauseSong : resumeSong}
                disabled={isLoading}
                title={isPlaying ? 'Pause' : 'Play'}
              >
                {isLoading ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : isPlaying ? (
                  <Pause className="h-5 w-5" />
                ) : (
                  <Play className="h-5 w-5 ml-0.5" />
                )}
              </Button>
              <Button variant="ghost" size="icon" onClick={nextSong} disabled={isLoading} title="Next song">
                <SkipForward className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleRepeat}
                className={isRepeat ? 'text-secondary' : ''}
                title={isRepeat ? 'Repeat on' : 'Repeat off'}
              >
                <Repeat className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex items-center gap-2 w-full">
              <span className="text-xs text-muted-foreground w-10 text-right tabular-nums">{formatTime(progressValue)}</span>
              <div className="flex-1 relative">
                <Slider
                  value={[progressValue]}
                  max={durationValue}
                  step={0.1}
                  onValueChange={handleProgressChange}
                  className="cursor-pointer"
                  disabled={isLoading || durationValue <= 0}
                  aria-label="Seek position"
                />
              </div>
              <span className="text-xs text-muted-foreground w-10 tabular-nums">
                {duration > 0 ? formatTime(durationValue) : formatTime(Number(currentSong.duration))}
              </span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-2 flex-1 justify-end">
            <Button variant="ghost" size="icon" onClick={handleVolumeToggle} title={isMuted || volume === 0 ? 'Unmute' : 'Mute'}>
              {isMuted || volume === 0 ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
            </Button>
            <Slider
              value={[volume]}
              max={100}
              step={1}
              onValueChange={(value) => {
                setVolume(value[0]);
                if (value[0] > 0) setIsMuted(false);
              }}
              className="w-24 cursor-pointer"
              aria-label="Volume"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
