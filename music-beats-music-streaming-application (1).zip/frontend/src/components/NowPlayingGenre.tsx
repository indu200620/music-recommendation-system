import { useMusicPlayer } from '../contexts/MusicPlayerContext';
import { useAddToListeningHistory } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Play, Pause, Star, ListPlus } from 'lucide-react';
import { useState } from 'react';
import SongRatingDialog from './SongRatingDialog';
import AddToPlaylistDialog from './AddToPlaylistDialog';
import type { YTMusicSong } from '../backend';

interface NowPlayingGenreProps {
  genreName: string;
  songs: YTMusicSong[];
}

export default function NowPlayingGenre({ genreName, songs }: NowPlayingGenreProps) {
  const { playSong, currentSong, isPlaying, pauseSong, resumeSong } = useMusicPlayer();
  const { identity } = useInternetIdentity();
  const addToHistory = useAddToListeningHistory();
  const [ratingDialogOpen, setRatingDialogOpen] = useState(false);
  const [playlistDialogOpen, setPlaylistDialogOpen] = useState(false);
  const [selectedSong, setSelectedSong] = useState<YTMusicSong | null>(null);

  const handlePlaySong = (song: YTMusicSong) => {
    if (currentSong?.id === song.id) {
      if (isPlaying) {
        pauseSong();
      } else {
        resumeSong();
      }
    } else {
      playSong(song, songs);
      if (identity) {
        addToHistory.mutate(song.id);
      }
    }
  };

  const handleRateSong = (song: YTMusicSong) => {
    setSelectedSong(song);
    setRatingDialogOpen(true);
  };

  const handleAddToPlaylist = (song: YTMusicSong) => {
    setSelectedSong(song);
    setPlaylistDialogOpen(true);
  };

  const formatDuration = (seconds: bigint) => {
    const mins = Math.floor(Number(seconds) / 60);
    const secs = Number(seconds) % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!songs || songs.length === 0) {
    return null;
  }

  return (
    <section className="py-12 bg-gradient-to-br from-primary/5 via-secondary/5 to-primary/5">
      <div className="container px-4">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Now Playing: {genreName}</h2>
          <p className="text-muted-foreground">
            {songs.length} {songs.length === 1 ? 'track' : 'tracks'} in this genre
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {songs.map((song) => {
            const isCurrentSong = currentSong?.id === song.id;
            const isCurrentlyPlaying = isCurrentSong && isPlaying;

            return (
              <Card
                key={song.id}
                className={`overflow-hidden hover:shadow-lg transition-all group ${
                  isCurrentSong ? 'ring-2 ring-primary shadow-xl' : ''
                }`}
              >
                <div className="relative aspect-square overflow-hidden bg-muted">
                  <img src={song.coverImage} alt={song.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Button
                      size="lg"
                      className="rounded-full w-16 h-16 bg-primary hover:bg-primary/90"
                      onClick={() => handlePlaySong(song)}
                    >
                      {isCurrentlyPlaying ? (
                        <Pause className="h-6 w-6 fill-current" />
                      ) : (
                        <Play className="h-6 w-6 fill-current" />
                      )}
                    </Button>
                  </div>
                  {isCurrentSong && (
                    <div className="absolute top-2 right-2 bg-primary text-primary-foreground px-2 py-1 rounded-full text-xs font-semibold">
                      {isCurrentlyPlaying ? 'Playing' : 'Paused'}
                    </div>
                  )}
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-sm mb-1 truncate">{song.title}</h3>
                  <p className="text-xs text-muted-foreground mb-2 truncate">{song.artist}</p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
                    <span className="truncate">{song.album}</span>
                    <span className="flex-shrink-0 ml-2">{formatDuration(song.duration)}</span>
                  </div>
                  {identity && (
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => handleRateSong(song)}
                      >
                        <Star className="h-3 w-3 mr-1" />
                        Rate
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => handleAddToPlaylist(song)}
                      >
                        <ListPlus className="h-3 w-3 mr-1" />
                        Add
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {selectedSong && (
        <>
          <SongRatingDialog
            open={ratingDialogOpen}
            onOpenChange={setRatingDialogOpen}
            song={selectedSong}
          />
          <AddToPlaylistDialog
            open={playlistDialogOpen}
            onOpenChange={setPlaylistDialogOpen}
            song={selectedSong}
          />
        </>
      )}
    </section>
  );
}
