import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useGetUserPlaylists, useAddSongsToPlaylist, useCreatePlaylist } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import type { YTMusicSong } from '../backend';
import { Plus } from 'lucide-react';

interface AddToPlaylistDialogProps {
  song: YTMusicSong;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function AddToPlaylistDialog({ song, open, onOpenChange }: AddToPlaylistDialogProps) {
  const { identity } = useInternetIdentity();
  const { data: playlists = [] } = useGetUserPlaylists(identity?.getPrincipal());
  const addToPlaylist = useAddSongsToPlaylist();
  const createPlaylist = useCreatePlaylist();
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [newPlaylistDescription, setNewPlaylistDescription] = useState('');

  const handleAddToExisting = async (playlistId: string) => {
    await addToPlaylist.mutateAsync({ playlistId, songs: [song] });
    onOpenChange(false);
  };

  const handleCreateNew = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlaylistName.trim()) return;

    const playlistId = await createPlaylist.mutateAsync({
      name: newPlaylistName.trim(),
      description: newPlaylistDescription.trim(),
      isPublic: false,
    });

    await addToPlaylist.mutateAsync({ playlistId, songs: [song] });
    onOpenChange(false);
    setNewPlaylistName('');
    setNewPlaylistDescription('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add to Playlist</DialogTitle>
          <DialogDescription>
            Add "{song.title}" to a playlist
          </DialogDescription>
        </DialogHeader>
        <Tabs defaultValue="existing" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="existing">Existing Playlist</TabsTrigger>
            <TabsTrigger value="new">New Playlist</TabsTrigger>
          </TabsList>
          <TabsContent value="existing" className="space-y-4">
            <ScrollArea className="h-[300px] w-full rounded-md border p-4">
              {playlists.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">No playlists yet. Create one!</p>
              ) : (
                <div className="space-y-2">
                  {playlists.map((playlist) => (
                    <Button
                      key={playlist.id}
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => handleAddToExisting(playlist.id)}
                      disabled={addToPlaylist.isPending}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      {playlist.name}
                    </Button>
                  ))}
                </div>
              )}
            </ScrollArea>
          </TabsContent>
          <TabsContent value="new">
            <form onSubmit={handleCreateNew} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="playlist-name">Playlist Name *</Label>
                <Input
                  id="playlist-name"
                  placeholder="My Awesome Playlist"
                  value={newPlaylistName}
                  onChange={(e) => setNewPlaylistName(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="playlist-description">Description (optional)</Label>
                <Input
                  id="playlist-description"
                  placeholder="Description..."
                  value={newPlaylistDescription}
                  onChange={(e) => setNewPlaylistDescription(e.target.value)}
                />
              </div>
              <Button type="submit" className="w-full" disabled={createPlaylist.isPending || !newPlaylistName.trim()}>
                {createPlaylist.isPending ? 'Creating...' : 'Create & Add Song'}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
