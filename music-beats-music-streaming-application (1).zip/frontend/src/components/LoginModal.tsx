import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { LogIn, Loader2 } from 'lucide-react';

interface LoginModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function LoginModal({ open, onOpenChange }: LoginModalProps) {
  const { login, loginStatus } = useInternetIdentity();

  const isLoggingIn = loginStatus === 'logging-in';

  const handleLogin = async () => {
    try {
      await login();
      onOpenChange(false);
    } catch (error: any) {
      console.error('Login error:', error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">Welcome to English Beats</DialogTitle>
          <DialogDescription className="text-center pt-2">
            Sign in with Internet Identity to access your personalized music experience
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col items-center gap-6 py-6">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
            <LogIn className="h-10 w-10 text-primary-foreground" />
          </div>
          <div className="text-center space-y-2">
            <h3 className="font-semibold">Secure Authentication</h3>
            <p className="text-sm text-muted-foreground max-w-sm">
              Internet Identity provides secure, anonymous authentication without passwords or personal data.
            </p>
          </div>
          <Button
            onClick={handleLogin}
            disabled={isLoggingIn}
            className="w-full max-w-xs bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-opacity"
            size="lg"
          >
            {isLoggingIn ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Connecting...
              </>
            ) : (
              <>
                <LogIn className="mr-2 h-5 w-5" />
                Sign In with Internet Identity
              </>
            )}
          </Button>
          <p className="text-xs text-muted-foreground text-center max-w-sm">
            A secure popup window will open for authentication. Please allow popups for this site.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
