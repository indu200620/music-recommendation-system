import { Button } from '@/components/ui/button';
import { FileText, Download } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';

export default function GenerateDocumentationButton() {
  const [isGenerating, setIsGenerating] = useState(false);

  const generateDocumentation = () => {
    setIsGenerating(true);
    
    try {
      // Create comprehensive HTML document with Word-compatible formatting
      const htmlContent = `
<!DOCTYPE html>
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
  <meta charset='utf-8'>
  <title>Music Beats - Project Documentation</title>
  <style>
    @page {
      size: A4;
      margin: 1in;
    }
    body {
      font-family: 'Calibri', 'Arial', sans-serif;
      font-size: 11pt;
      line-height: 1.6;
      color: #000000;
      max-width: 8.5in;
      margin: 0 auto;
      padding: 20px;
    }
    h1 {
      font-size: 24pt;
      font-weight: bold;
      color: #5B21B6;
      margin-top: 24pt;
      margin-bottom: 12pt;
      page-break-after: avoid;
    }
    h2 {
      font-size: 18pt;
      font-weight: bold;
      color: #7C3AED;
      margin-top: 18pt;
      margin-bottom: 10pt;
      page-break-after: avoid;
    }
    h3 {
      font-size: 14pt;
      font-weight: bold;
      color: #8B5CF6;
      margin-top: 12pt;
      margin-bottom: 8pt;
      page-break-after: avoid;
    }
    p {
      margin: 6pt 0;
      text-align: justify;
    }
    ul, ol {
      margin: 6pt 0;
      padding-left: 30pt;
    }
    li {
      margin: 3pt 0;
    }
    table {
      border-collapse: collapse;
      width: 100%;
      margin: 12pt 0;
      page-break-inside: avoid;
    }
    th {
      background-color: #5B21B6;
      color: white;
      font-weight: bold;
      padding: 8pt;
      text-align: left;
      border: 1pt solid #5B21B6;
    }
    td {
      padding: 8pt;
      border: 1pt solid #D1D5DB;
    }
    tr:nth-child(even) {
      background-color: #F9FAFB;
    }
    .cover-page {
      text-align: center;
      page-break-after: always;
      padding-top: 100pt;
    }
    .cover-title {
      font-size: 36pt;
      font-weight: bold;
      color: #5B21B6;
      margin-bottom: 20pt;
    }
    .cover-subtitle {
      font-size: 18pt;
      color: #7C3AED;
      margin-bottom: 40pt;
    }
    .cover-info {
      font-size: 12pt;
      color: #6B7280;
      margin-top: 60pt;
    }
    .section {
      page-break-before: auto;
      margin-bottom: 20pt;
    }
    .code-block {
      background-color: #F3F4F6;
      border: 1pt solid #D1D5DB;
      padding: 10pt;
      font-family: 'Courier New', monospace;
      font-size: 9pt;
      margin: 10pt 0;
      white-space: pre-wrap;
      word-wrap: break-word;
    }
    .highlight {
      background-color: #FEF3C7;
      padding: 2pt 4pt;
      font-weight: bold;
    }
    .image-container {
      text-align: center;
      margin: 20pt 0;
      page-break-inside: avoid;
    }
    .image-caption {
      font-size: 10pt;
      font-style: italic;
      color: #6B7280;
      margin-top: 6pt;
    }
    img {
      max-width: 100%;
      height: auto;
      border: 1pt solid #D1D5DB;
    }
  </style>
</head>
<body>

<!-- Cover Page -->
<div class="cover-page">
  <div class="cover-title">Music Beats</div>
  <div class="cover-subtitle">Music Streaming & Recommendation System</div>
  <div class="cover-subtitle">Comprehensive Project Documentation</div>
  <div class="cover-info">
    <p>Version 1.0</p>
    <p>Date: ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
    <p>Built with Caffeine.ai on Internet Computer</p>
  </div>
</div>

<!-- Table of Contents -->
<div class="section">
  <h1>Table of Contents</h1>
  <ol>
    <li>Project Overview</li>
    <li>System Architecture</li>
    <li>Detailed Feature Explanation</li>
    <li>Implementation Breakdown</li>
    <li>Tools and Technologies</li>
    <li>Data Flow Diagrams and Schema</li>
    <li>UI and Theming</li>
    <li>Legal Compliance and Song Data</li>
    <li>Testing and Deployment</li>
    <li>Conclusion</li>
  </ol>
</div>

<!-- 1. Project Overview -->
<div class="section">
  <h1>1. Project Overview</h1>
  
  <h2>1.1 Purpose</h2>
  <p>Music Beats is a comprehensive music streaming and recommendation system designed to provide personalized music experiences for users interested in both English and Hindi songs. The application leverages modern web technologies and blockchain infrastructure to deliver a secure, scalable, and user-friendly platform for music discovery and playback.</p>
  
  <h2>1.2 Key Objectives</h2>
  <ul>
    <li>Provide legal streaming of public-domain English and Hindi songs via YouTube Music API and Spotify API integration</li>
    <li>Implement intelligent recommendation algorithms based on user listening history and preferences</li>
    <li>Enable secure user authentication through Internet Identity on the Internet Computer blockchain</li>
    <li>Facilitate playlist creation, management, and sharing among users</li>
    <li>Track comprehensive listening history and user ratings for improved recommendations</li>
  </ul>
  
  <h2>1.3 Application Flow</h2>
  <p>The application follows a streamlined user journey:</p>
  <ol>
    <li><strong>Authentication:</strong> Users log in using Internet Identity through an in-app modal interface</li>
    <li><strong>Profile Setup:</strong> First-time users create their profile with username and bio</li>
    <li><strong>Music Discovery:</strong> Users browse recommended songs, search for tracks, and explore featured playlists</li>
    <li><strong>Playback:</strong> Real-time audio streaming with comprehensive player controls</li>
    <li><strong>Engagement:</strong> Users rate songs, create playlists, and track their listening history</li>
    <li><strong>Personalization:</strong> The system learns from user behavior to provide increasingly accurate recommendations</li>
  </ol>
  
  <h2>1.4 Target Audience</h2>
  <p>Music Beats is designed for music enthusiasts who appreciate both English and Hindi music, seeking a personalized streaming experience with intelligent recommendations and social playlist sharing capabilities.</p>
</div>

<!-- 2. System Architecture -->
<div class="section">
  <h1>2. System Architecture</h1>
  
  <h2>2.1 High-Level Architecture</h2>
  <p>Music Beats employs a modern, decentralized architecture leveraging the Internet Computer blockchain for backend services and traditional web technologies for the frontend.</p>
  
  <h3>2.1.1 Frontend Layer</h3>
  <ul>
    <li><strong>Framework:</strong> React 19 with TypeScript for type-safe component development</li>
    <li><strong>Build Tool:</strong> Vite for fast development and optimized production builds</li>
    <li><strong>Styling:</strong> Tailwind CSS with custom OKLCH color system (deep violet and gold theme)</li>
    <li><strong>State Management:</strong> React Query (TanStack Query) for server state and React Context for UI state</li>
    <li><strong>UI Components:</strong> Shadcn/ui component library built on Radix UI primitives</li>
  </ul>
  
  <h3>2.1.2 Backend Layer</h3>
  <ul>
    <li><strong>Language:</strong> Motoko - Internet Computer's native programming language</li>
    <li><strong>Platform:</strong> Internet Computer blockchain for decentralized, tamper-proof data storage</li>
    <li><strong>Canister Architecture:</strong> Single backend canister handling all business logic and data persistence</li>
    <li><strong>Storage:</strong> Caffeine Blob Storage for user profile avatars and large binary data</li>
  </ul>
  
  <h3>2.1.3 External API Integration</h3>
  <ul>
    <li><strong>YouTube Music API:</strong> Primary source for song metadata and streaming URLs</li>
    <li><strong>Spotify API:</strong> Secondary source for additional catalog and preview tracks</li>
    <li><strong>HTTP Outcalls:</strong> Internet Computer's HTTP outcall feature for secure API communication</li>
  </ul>
  
  <h3>2.1.4 Authentication Layer</h3>
  <ul>
    <li><strong>Internet Identity:</strong> Decentralized authentication system providing secure, privacy-preserving user login</li>
    <li><strong>Role-Based Access Control:</strong> Admin, user, and guest roles with appropriate permissions</li>
    <li><strong>Session Management:</strong> Secure session handling with automatic token refresh</li>
  </ul>
  
  <h2>2.2 Component Interaction</h2>
  <p>The frontend communicates with the backend canister through the Internet Computer agent, which handles authentication, request signing, and response verification. External API calls are proxied through the backend to maintain security and prevent CORS issues.</p>
</div>

<!-- 3. Detailed Feature Explanation -->
<div class="section">
  <h1>3. Detailed Feature Explanation</h1>
  
  <h2>3.1 User Registration and Profiles</h2>
  <h3>Profile Setup</h3>
  <p>When users first authenticate with Internet Identity, they are prompted to create a profile. The profile includes:</p>
  <ul>
    <li><strong>Username:</strong> Unique identifier displayed throughout the application</li>
    <li><strong>Bio:</strong> Optional personal description</li>
    <li><strong>Favorite Genres:</strong> User's preferred music genres for recommendation tuning</li>
    <li><strong>Favorite Artists:</strong> Preferred artists to influence recommendations</li>
    <li><strong>Profile Avatar:</strong> Custom image stored using blob storage</li>
  </ul>
  
  <h3>Profile Management</h3>
  <p>Users can edit their profiles at any time through the profile dropdown menu. Changes are immediately persisted to the backend canister and reflected across the application.</p>
  
  <h2>3.2 Song Search and Playback</h2>
  <h3>Search Functionality</h3>
  <p>The universal search bar in the header allows users to search for songs, artists, and albums. Search queries are sent to both YouTube Music API and Spotify API, with results aggregated and displayed with complete metadata including:</p>
  <ul>
    <li>Song title and artist name</li>
    <li>Album information and cover art</li>
    <li>Duration and genre</li>
    <li>Playable audio URLs (YouTube IDs or Spotify preview URLs)</li>
  </ul>
  
  <h3>Audio Playback</h3>
  <p>Music Beats implements a hybrid audio player supporting two playback methods:</p>
  <ul>
    <li><strong>YouTube IFrame API:</strong> For YouTube-sourced tracks with full-length playback</li>
    <li><strong>HTML5 Audio:</strong> For Spotify preview URLs and direct audio streams</li>
  </ul>
  
  <p>The player features comprehensive controls:</p>
  <ul>
    <li>Play/Pause toggle</li>
    <li>Skip forward and backward through playlist</li>
    <li>Seek functionality with interactive progress bar</li>
    <li>Volume control</li>
    <li>Repeat mode (off, repeat all, repeat one)</li>
    <li>Shuffle mode for randomized playback</li>
    <li>Real-time progress tracking with accurate time display</li>
  </ul>
  
  <h2>3.3 Playlist Management</h2>
  <h3>Creating Playlists</h3>
  <p>Users can create custom playlists with the following properties:</p>
  <ul>
    <li><strong>Name:</strong> Descriptive playlist title</li>
    <li><strong>Description:</strong> Optional details about the playlist</li>
    <li><strong>Visibility:</strong> Public (visible to all users) or private</li>
    <li><strong>Songs:</strong> Collection of tracks from search results or recommendations</li>
  </ul>
  
  <h3>Playlist Operations</h3>
  <ul>
    <li><strong>Add Songs:</strong> Add tracks from search results or recommendations</li>
    <li><strong>Remove Songs:</strong> Delete tracks from playlists</li>
    <li><strong>Edit Details:</strong> Update playlist name, description, and visibility</li>
    <li><strong>Delete Playlist:</strong> Permanently remove playlists</li>
    <li><strong>Share Playlist:</strong> Grant access to specific users</li>
  </ul>
  
  <h2>3.4 Ratings and Listening History</h2>
  <h3>Song Rating System</h3>
  <p>Users can rate songs on a 1-5 star scale. Ratings are stored with timestamps and used to:</p>
  <ul>
    <li>Improve recommendation accuracy</li>
    <li>Identify user preferences and patterns</li>
    <li>Calculate song popularity metrics</li>
    <li>Enable collaborative filtering</li>
  </ul>
  
  <h3>Listening History Tracking</h3>
  <p>Every song playback is automatically recorded with:</p>
  <ul>
    <li>Song ID for track identification</li>
    <li>Timestamp for temporal analysis</li>
    <li>User ID for personalization</li>
  </ul>
  
  <p>This data powers the "Recently Played" section and feeds into the recommendation engine.</p>
  
  <h2>3.5 Recommendation Engine</h2>
  <h3>Algorithm Overview</h3>
  <p>Music Beats employs a hybrid recommendation system combining:</p>
  
  <h4>Collaborative Filtering</h4>
  <ul>
    <li>Analyzes listening patterns across all users</li>
    <li>Identifies users with similar tastes</li>
    <li>Recommends songs enjoyed by similar users</li>
  </ul>
  
  <h4>Content-Based Filtering</h4>
  <ul>
    <li>Examines song metadata (genre, artist, album)</li>
    <li>Matches user's favorite genres and artists</li>
    <li>Suggests similar tracks based on audio characteristics</li>
  </ul>
  
  <h4>Rating-Based Weighting</h4>
  <ul>
    <li>Prioritizes highly-rated songs</li>
    <li>Reduces recommendations for low-rated tracks</li>
    <li>Balances exploration and exploitation</li>
  </ul>
  
  <h3>Dynamic Updates</h3>
  <p>Recommendations are recalculated based on user behavior, ensuring fresh and relevant suggestions as listening patterns evolve.</p>
</div>

<!-- 4. Implementation Breakdown -->
<div class="section">
  <h1>4. Implementation Breakdown</h1>
  
  <h2>4.1 Frontend Architecture</h2>
  
  <h3>4.1.1 Core Application (App.tsx)</h3>
  <p>The main application component orchestrates:</p>
  <ul>
    <li>Theme provider initialization for dark/light mode support</li>
    <li>Internet Identity authentication state management</li>
    <li>Music player context for global playback state</li>
    <li>Profile setup modal for first-time users</li>
    <li>Main layout rendering (header, content, footer, audio player)</li>
  </ul>
  
  <h3>4.1.2 Audio Player (AudioPlayer.tsx)</h3>
  <p>Fixed bottom player component featuring:</p>
  <ul>
    <li>Hybrid playback engine (YouTube IFrame + HTML5 Audio)</li>
    <li>Real-time progress tracking with seek functionality</li>
    <li>Volume controls with mute toggle</li>
    <li>Playback mode controls (repeat, shuffle)</li>
    <li>Auto-skip on track completion or error</li>
    <li>Error handling with user-friendly alerts</li>
  </ul>
  
  <h3>4.1.3 Header Component (Header.tsx)</h3>
  <p>Application header providing:</p>
  <ul>
    <li>Music Beats branding with logo</li>
    <li>Universal search bar for songs, artists, and albums</li>
    <li>Theme toggle (dark/light mode)</li>
    <li>Authentication controls (login/logout)</li>
    <li>User profile dropdown with edit and navigation options</li>
  </ul>
  
  <h3>4.1.4 Home Page (HomePage.tsx)</h3>
  <p>Main landing page displaying:</p>
  <ul>
    <li>Hero section with app branding and description</li>
    <li>Login prompt for guest users</li>
    <li>Recently played tracks for authenticated users</li>
    <li>Recommended songs section with 20 mixed English and Hindi tracks</li>
    <li>Featured public playlists</li>
  </ul>
  
  <h3>4.1.5 Recommended Songs (RecommendedSongs.tsx)</h3>
  <p>Displays curated song recommendations with:</p>
  <ul>
    <li>Complete song metadata (title, artist, album, duration)</li>
    <li>Cover art display</li>
    <li>Play button for immediate playback</li>
    <li>Rating dialog for user feedback</li>
    <li>Add to playlist functionality</li>
    <li>Automatic listening history tracking</li>
  </ul>
  
  <h3>4.1.6 Login Modal (LoginModal.tsx)</h3>
  <p>In-app authentication interface featuring:</p>
  <ul>
    <li>Internet Identity branding and instructions</li>
    <li>Centered popup window for authentication</li>
    <li>Error handling and retry logic</li>
    <li>Smooth transition to profile setup</li>
  </ul>
  
  <h2>4.2 Backend Workflow</h2>
  
  <h3>4.2.1 Data Structures</h3>
  <p>The backend maintains several key data structures:</p>
  <ul>
    <li><strong>UserProfile:</strong> User information and preferences</li>
    <li><strong>Playlist:</strong> Playlist metadata and song collections</li>
    <li><strong>SongRating:</strong> User ratings with timestamps</li>
    <li><strong>ListeningHistoryEntry:</strong> Playback tracking data</li>
    <li><strong>YTMusicSong:</strong> Complete song metadata from APIs</li>
  </ul>
  
  <h3>4.2.2 API Endpoints</h3>
  <p>The backend exposes the following key endpoints:</p>
  
  <h4>User Management</h4>
  <ul>
    <li>getCallerUserProfile() - Retrieve current user's profile</li>
    <li>saveCallerUserProfile() - Create or update user profile</li>
    <li>getUserProfile() - Get specific user's profile (admin only)</li>
    <li>getAllPublicProfiles() - List all user profiles</li>
  </ul>
  
  <h4>Playlist Operations</h4>
  <ul>
    <li>createPlaylist() - Create new playlist</li>
    <li>addSongsToPlaylist() - Add tracks to playlist</li>
    <li>removeSongFromPlaylist() - Remove track from playlist</li>
    <li>updatePlaylist() - Modify playlist details</li>
    <li>deletePlaylist() - Remove playlist</li>
    <li>sharePlaylistWithUser() - Grant access to user</li>
    <li>getUserPlaylists() - Get user's playlists</li>
    <li>getPublicPlaylists() - List public playlists</li>
    <li>getSharedPlaylists() - Get playlists shared with user</li>
  </ul>
  
  <h4>Rating and History</h4>
  <ul>
    <li>rateSong() - Submit song rating</li>
    <li>getSongRatings() - Get all ratings for a song</li>
    <li>getUserRatings() - Get user's rating history</li>
    <li>addToListeningHistory() - Record song playback</li>
    <li>getListeningHistory() - Retrieve user's listening history</li>
  </ul>
  
  <h4>Music Discovery</h4>
  <ul>
    <li>searchSongs() - Search for tracks via APIs</li>
    <li>getSongsByGenre() - Filter by genre</li>
    <li>getSongsByArtist() - Filter by artist</li>
    <li>getRecommendedSongs() - Get personalized recommendations</li>
  </ul>
  
  <h3>4.2.3 Authorization</h3>
  <p>The backend implements role-based access control with three roles:</p>
  <ul>
    <li><strong>Guest:</strong> Limited access to public content</li>
    <li><strong>User:</strong> Full access to personal features and content creation</li>
    <li><strong>Admin:</strong> System administration and user management</li>
  </ul>
  
  <h2>4.3 Frontend-Backend Communication</h2>
  <p>Communication is handled through React Query hooks in useQueries.ts:</p>
  <ul>
    <li>Automatic request caching and invalidation</li>
    <li>Optimistic updates for improved UX</li>
    <li>Error handling and retry logic</li>
    <li>Loading state management</li>
    <li>Background data refetching</li>
  </ul>
</div>

<!-- 5. Tools and Technologies -->
<div class="section">
  <h1>5. Tools and Technologies</h1>
  
  <table>
    <thead>
      <tr>
        <th>Category</th>
        <th>Technology</th>
        <th>Version</th>
        <th>Purpose</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Frontend Framework</td>
        <td>React</td>
        <td>19.1.0</td>
        <td>Component-based UI development</td>
      </tr>
      <tr>
        <td>Language</td>
        <td>TypeScript</td>
        <td>5.8.3</td>
        <td>Type-safe JavaScript development</td>
      </tr>
      <tr>
        <td>Build Tool</td>
        <td>Vite</td>
        <td>5.4.1</td>
        <td>Fast development server and optimized builds</td>
      </tr>
      <tr>
        <td>Styling</td>
        <td>Tailwind CSS</td>
        <td>3.4.17</td>
        <td>Utility-first CSS framework</td>
      </tr>
      <tr>
        <td>State Management</td>
        <td>React Query</td>
        <td>5.24.0</td>
        <td>Server state management and caching</td>
      </tr>
      <tr>
        <td>UI Components</td>
        <td>Shadcn/ui</td>
        <td>Latest</td>
        <td>Pre-built accessible components</td>
      </tr>
      <tr>
        <td>UI Primitives</td>
        <td>Radix UI</td>
        <td>Various</td>
        <td>Unstyled, accessible component primitives</td>
      </tr>
      <tr>
        <td>Icons</td>
        <td>Lucide React</td>
        <td>0.511.0</td>
        <td>Icon library for UI elements</td>
      </tr>
      <tr>
        <td>Theme Management</td>
        <td>next-themes</td>
        <td>0.4.6</td>
        <td>Dark/light mode support</td>
      </tr>
      <tr>
        <td>Backend Language</td>
        <td>Motoko</td>
        <td>Latest</td>
        <td>Internet Computer native language</td>
      </tr>
      <tr>
        <td>Blockchain Platform</td>
        <td>Internet Computer</td>
        <td>Latest</td>
        <td>Decentralized backend infrastructure</td>
      </tr>
      <tr>
        <td>Authentication</td>
        <td>Internet Identity</td>
        <td>3.3.0</td>
        <td>Decentralized user authentication</td>
      </tr>
      <tr>
        <td>Storage</td>
        <td>Caffeine Blob Storage</td>
        <td>Latest</td>
        <td>Large file and binary data storage</td>
      </tr>
      <tr>
        <td>API Integration</td>
        <td>YouTube Music API</td>
        <td>v3</td>
        <td>Song metadata and streaming</td>
      </tr>
      <tr>
        <td>API Integration</td>
        <td>Spotify API</td>
        <td>v1</td>
        <td>Additional song catalog and previews</td>
      </tr>
      <tr>
        <td>HTTP Client</td>
        <td>IC HTTP Outcalls</td>
        <td>Latest</td>
        <td>Secure external API communication</td>
      </tr>
      <tr>
        <td>Notifications</td>
        <td>Sonner</td>
        <td>1.7.4</td>
        <td>Toast notifications</td>
      </tr>
    </tbody>
  </table>
</div>

<!-- 6. Data Flow Diagrams and Schema -->
<div class="section">
  <h1>6. Data Flow Diagrams and Schema</h1>
  
  <h2>6.1 User Interaction Flow</h2>
  <div class="image-container">
    <img src="/assets/generated/user-flow-diagram.dim_800x600.png" alt="User Flow Diagram" />
    <p class="image-caption">Figure 1: User interaction flow from authentication to music playback</p>
  </div>
  
  <h2>6.2 System Architecture Diagram</h2>
  <div class="image-container">
    <img src="/assets/generated/system-architecture-diagram.dim_800x600.png" alt="System Architecture" />
    <p class="image-caption">Figure 2: High-level system architecture showing frontend, backend, and API integration</p>
  </div>
  
  <h2>6.3 API Data Flow</h2>
  <div class="image-container">
    <img src="/assets/generated/api-data-flow-diagram.dim_800x600.png" alt="API Data Flow" />
    <p class="image-caption">Figure 3: Data flow between frontend, backend canister, and external APIs</p>
  </div>
  
  <h2>6.4 Database Schema</h2>
  <div class="image-container">
    <img src="/assets/generated/database-schema-diagram.dim_800x600.png" alt="Database Schema" />
    <p class="image-caption">Figure 4: Backend data structures and relationships</p>
  </div>
  
  <h2>6.5 Data Structure Details</h2>
  
  <h3>UserProfile</h3>
  <table>
    <thead>
      <tr>
        <th>Field</th>
        <th>Type</th>
        <th>Description</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>userId</td>
        <td>Principal</td>
        <td>Unique user identifier from Internet Identity</td>
      </tr>
      <tr>
        <td>username</td>
        <td>Text</td>
        <td>Display name chosen by user</td>
      </tr>
      <tr>
        <td>bio</td>
        <td>Text</td>
        <td>Optional user biography</td>
      </tr>
      <tr>
        <td>favoriteGenres</td>
        <td>[Text]</td>
        <td>Array of preferred music genres</td>
      </tr>
      <tr>
        <td>favoriteArtists</td>
        <td>[Text]</td>
        <td>Array of preferred artists</td>
      </tr>
      <tr>
        <td>profileImage</td>
        <td>?ExternalBlob</td>
        <td>Optional profile avatar stored in blob storage</td>
      </tr>
    </tbody>
  </table>
  
  <h3>Playlist</h3>
  <table>
    <thead>
      <tr>
        <th>Field</th>
        <th>Type</th>
        <th>Description</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>id</td>
        <td>Text</td>
        <td>Unique playlist identifier</td>
      </tr>
      <tr>
        <td>owner</td>
        <td>Principal</td>
        <td>User who created the playlist</td>
      </tr>
      <tr>
        <td>name</td>
        <td>Text</td>
        <td>Playlist title</td>
      </tr>
      <tr>
        <td>description</td>
        <td>Text</td>
        <td>Playlist description</td>
      </tr>
      <tr>
        <td>songs</td>
        <td>[YTMusicSong]</td>
        <td>Array of songs in the playlist</td>
      </tr>
      <tr>
        <td>isPublic</td>
        <td>Bool</td>
        <td>Visibility flag (public or private)</td>
      </tr>
      <tr>
        <td>sharedWith</td>
        <td>[Principal]</td>
        <td>Array of users with access to private playlist</td>
      </tr>
    </tbody>
  </table>
  
  <h3>SongRating</h3>
  <table>
    <thead>
      <tr>
        <th>Field</th>
        <th>Type</th>
        <th>Description</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>userId</td>
        <td>Principal</td>
        <td>User who submitted the rating</td>
      </tr>
      <tr>
        <td>songId</td>
        <td>Text</td>
        <td>Identifier of the rated song</td>
      </tr>
      <tr>
        <td>rating</td>
        <td>Nat</td>
        <td>Rating value (1-5 stars)</td>
      </tr>
      <tr>
        <td>timestamp</td>
        <td>Time</td>
        <td>When the rating was submitted</td>
      </tr>
    </tbody>
  </table>
  
  <h3>ListeningHistoryEntry</h3>
  <table>
    <thead>
      <tr>
        <th>Field</th>
        <th>Type</th>
        <th>Description</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>userId</td>
        <td>Principal</td>
        <td>User who played the song</td>
      </tr>
      <tr>
        <td>songId</td>
        <td>Text</td>
        <td>Identifier of the played song</td>
      </tr>
      <tr>
        <td>timestamp</td>
        <td>Time</td>
        <td>When the song was played</td>
      </tr>
    </tbody>
  </table>
  
  <h3>YTMusicSong</h3>
  <table>
    <thead>
      <tr>
        <th>Field</th>
        <th>Type</th>
        <th>Description</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>id</td>
        <td>Text</td>
        <td>Unique song identifier</td>
      </tr>
      <tr>
        <td>title</td>
        <td>Text</td>
        <td>Song title</td>
      </tr>
      <tr>
        <td>artist</td>
        <td>Text</td>
        <td>Artist name</td>
      </tr>
      <tr>
        <td>album</td>
        <td>Text</td>
        <td>Album name</td>
      </tr>
      <tr>
        <td>genre</td>
        <td>Text</td>
        <td>Music genre</td>
      </tr>
      <tr>
        <td>duration</td>
        <td>Nat</td>
        <td>Song duration in seconds</td>
      </tr>
      <tr>
        <td>youtubeId</td>
        <td>Text</td>
        <td>YouTube video ID for playback</td>
      </tr>
      <tr>
        <td>coverImage</td>
        <td>Text</td>
        <td>URL to album cover art</td>
      </tr>
      <tr>
        <td>audioPreviewUrl</td>
        <td>Text</td>
        <td>Direct audio URL (Spotify preview)</td>
      </tr>
    </tbody>
  </table>
</div>

<!-- 7. UI and Theming -->
<div class="section">
  <h1>7. UI and Theming</h1>
  
  <h2>7.1 Design Philosophy</h2>
  <p>Music Beats employs a modern, elegant design system centered around a deep violet and gold color palette. The design emphasizes:</p>
  <ul>
    <li>Clean, uncluttered interfaces</li>
    <li>Intuitive navigation and controls</li>
    <li>Responsive layouts for all device sizes</li>
    <li>Accessible components meeting WCAG standards</li>
    <li>Smooth animations and transitions</li>
  </ul>
  
  <h2>7.2 Color System</h2>
  <p>The application uses an OKLCH-based color system for consistent, perceptually uniform colors across light and dark modes:</p>
  
  <h3>Primary Colors</h3>
  <ul>
    <li><strong>Primary (Deep Violet):</strong> oklch(0.55 0.25 285) - Main brand color</li>
    <li><strong>Secondary (Gold):</strong> oklch(0.75 0.15 85) - Accent and highlights</li>
    <li><strong>Accent:</strong> oklch(0.65 0.20 285) - Interactive elements</li>
  </ul>
  
  <h3>Semantic Colors</h3>
  <ul>
    <li><strong>Background:</strong> oklch(0.98 0.01 285) light / oklch(0.15 0.02 285) dark</li>
    <li><strong>Foreground:</strong> oklch(0.15 0.02 285) light / oklch(0.95 0.01 285) dark</li>
    <li><strong>Muted:</strong> oklch(0.92 0.02 285) light / oklch(0.25 0.03 285) dark</li>
    <li><strong>Border:</strong> oklch(0.88 0.02 285) light / oklch(0.30 0.03 285) dark</li>
  </ul>
  
  <h2>7.3 Typography</h2>
  <ul>
    <li><strong>Font Family:</strong> System font stack for optimal performance</li>
    <li><strong>Headings:</strong> Bold weights with generous spacing</li>
    <li><strong>Body Text:</strong> Regular weight, 1.6 line height for readability</li>
    <li><strong>Code:</strong> Monospace font for technical content</li>
  </ul>
  
  <h2>7.4 Responsive Design</h2>
  <p>The application adapts seamlessly to different screen sizes:</p>
  <ul>
    <li><strong>Mobile (< 768px):</strong> Single-column layout, touch-optimized controls</li>
    <li><strong>Tablet (768px - 1024px):</strong> Two-column layouts where appropriate</li>
    <li><strong>Desktop (> 1024px):</strong> Multi-column layouts, expanded navigation</li>
  </ul>
  
  <h2>7.5 Audio Player Interface</h2>
  <p>The fixed bottom audio player features:</p>
  <ul>
    <li>Album art thumbnail with current track information</li>
    <li>Large, touch-friendly playback controls</li>
    <li>Interactive progress bar with time display</li>
    <li>Volume slider with mute toggle</li>
    <li>Repeat and shuffle mode indicators</li>
    <li>Responsive layout collapsing on mobile devices</li>
  </ul>
  
  <h2>7.6 Accessibility Features</h2>
  <ul>
    <li>ARIA labels on all interactive elements</li>
    <li>Keyboard navigation support</li>
    <li>Focus indicators for keyboard users</li>
    <li>High contrast mode compatibility</li>
    <li>Screen reader friendly markup</li>
    <li>Reduced motion support for animations</li>
  </ul>
</div>

<!-- 8. Legal Compliance and Song Data -->
<div class="section">
  <h1>8. Legal Compliance and Song Data</h1>
  
  <h2>8.1 Content Licensing</h2>
  <p>Music Beats operates within legal frameworks for music streaming:</p>
  
  <h3>YouTube Music API</h3>
  <ul>
    <li>All content accessed through official YouTube Music API</li>
    <li>Playback occurs through YouTube's embedded player</li>
    <li>Complies with YouTube's Terms of Service</li>
    <li>No direct downloading or storage of copyrighted content</li>
  </ul>
  
  <h3>Spotify API</h3>
  <ul>
    <li>Uses official Spotify Web API for metadata and previews</li>
    <li>Preview clips limited to 30 seconds as per Spotify guidelines</li>
    <li>Adheres to Spotify Developer Terms</li>
    <li>Proper attribution and branding as required</li>
  </ul>
  
  <h2>8.2 Data Sources</h2>
  <p>The application focuses on legal, publicly accessible music:</p>
  <ul>
    <li><strong>Public Domain Songs:</strong> Tracks with expired copyrights</li>
    <li><strong>Creative Commons Licensed Music:</strong> Properly attributed content</li>
    <li><strong>API-Provided Previews:</strong> Official preview clips from Spotify</li>
    <li><strong>YouTube Content:</strong> Videos available through YouTube's platform</li>
  </ul>
  
  <h2>8.3 User-Generated Content</h2>
  <p>User contributions are limited to:</p>
  <ul>
    <li>Playlist creation and curation</li>
    <li>Song ratings and reviews</li>
    <li>Profile information and avatars</li>
  </ul>
  <p>No user-uploaded audio files are stored or distributed.</p>
  
  <h2>8.4 Privacy and Data Protection</h2>
  <ul>
    <li><strong>Decentralized Authentication:</strong> Internet Identity provides privacy-preserving login</li>
    <li><strong>Data Ownership:</strong> Users control their profile and listening data</li>
    <li><strong>No Third-Party Tracking:</strong> No analytics or advertising trackers</li>
    <li><strong>Transparent Data Usage:</strong> Clear communication about data collection and use</li>
  </ul>
  
  <h2>8.5 Copyright Compliance</h2>
  <p>The application implements several measures to ensure copyright compliance:</p>
  <ul>
    <li>No direct storage of copyrighted audio files</li>
    <li>All playback through official API channels</li>
    <li>Proper attribution of artists and content creators</li>
    <li>Respect for content removal requests</li>
    <li>Regular audits of available content</li>
  </ul>
</div>

<!-- 9. Testing and Deployment -->
<div class="section">
  <h1>9. Testing and Deployment</h1>
  
  <h2>9.1 Development Environment</h2>
  <p>Local development setup:</p>
  <ul>
    <li><strong>DFX SDK:</strong> Internet Computer development kit</li>
    <li><strong>Local Replica:</strong> Local blockchain for testing</li>
    <li><strong>Vite Dev Server:</strong> Fast hot-reload development server</li>
    <li><strong>TypeScript Compiler:</strong> Type checking during development</li>
  </ul>
  
  <h2>9.2 Testing Strategy</h2>
  
  <h3>Frontend Testing</h3>
  <ul>
    <li><strong>Component Testing:</strong> Individual component functionality</li>
    <li><strong>Integration Testing:</strong> Component interaction and data flow</li>
    <li><strong>User Flow Testing:</strong> End-to-end user journeys</li>
    <li><strong>Responsive Testing:</strong> Cross-device compatibility</li>
    <li><strong>Browser Testing:</strong> Chrome, Firefox, Safari, Edge compatibility</li>
  </ul>
  
  <h3>Backend Testing</h3>
  <ul>
    <li><strong>Unit Tests:</strong> Individual function testing</li>
    <li><strong>Integration Tests:</strong> Canister method interactions</li>
    <li><strong>Authorization Tests:</strong> Role-based access control verification</li>
    <li><strong>Data Persistence Tests:</strong> Storage and retrieval validation</li>
  </ul>
  
  <h3>Audio Playback Testing</h3>
  <ul>
    <li><strong>YouTube Playback:</strong> IFrame API integration</li>
    <li><strong>Spotify Previews:</strong> HTML5 Audio functionality</li>
    <li><strong>Error Handling:</strong> Unavailable track scenarios</li>
    <li><strong>Auto-Skip:</strong> Playlist progression</li>
    <li><strong>Progress Tracking:</strong> Accurate time display</li>
  </ul>
  
  <h2>9.3 Deployment Process</h2>
  
  <h3>Internet Computer Deployment</h3>
  <ol>
    <li><strong>Build Frontend:</strong> Vite production build with optimizations</li>
    <li><strong>Generate Bindings:</strong> TypeScript interfaces from Motoko backend</li>
    <li><strong>Deploy Backend Canister:</strong> Upload Motoko code to IC</li>
    <li><strong>Deploy Frontend Assets:</strong> Upload static files to asset canister</li>
    <li><strong>Configure Domains:</strong> Set up custom domain (optional)</li>
  </ol>
  
  <h3>Deployment Commands</h3>
  <div class="code-block">
# Install dependencies
pnpm install

# Create canisters
dfx canister create backend
dfx canister create frontend

# Generate TypeScript bindings
dfx generate backend

# Deploy to local replica
dfx deploy

# Deploy to IC mainnet
dfx deploy --network ic
  </div>
  
  <h2>9.4 Performance Optimization</h2>
  <ul>
    <li><strong>Code Splitting:</strong> Lazy loading of route components</li>
    <li><strong>Image Optimization:</strong> Compressed assets with appropriate formats</li>
    <li><strong>Caching Strategy:</strong> React Query cache configuration</li>
    <li><strong>Bundle Size:</strong> Tree shaking and minification</li>
    <li><strong>CDN Delivery:</strong> Asset canister serves static files efficiently</li>
  </ul>
  
  <h2>9.5 Monitoring and Maintenance</h2>
  <ul>
    <li><strong>Error Tracking:</strong> Console logging and error boundaries</li>
    <li><strong>Performance Monitoring:</strong> Load times and interaction metrics</li>
    <li><strong>Canister Cycles:</strong> Regular monitoring of computation resources</li>
    <li><strong>API Rate Limits:</strong> Tracking external API usage</li>
    <li><strong>User Feedback:</strong> In-app feedback mechanisms</li>
  </ul>
</div>

<!-- 10. Conclusion -->
<div class="section">
  <h1>10. Conclusion</h1>
  
  <h2>10.1 Project Achievements</h2>
  <p>Music Beats successfully delivers a comprehensive music streaming and recommendation platform with the following key achievements:</p>
  
  <ul>
    <li><strong>Decentralized Architecture:</strong> Leverages Internet Computer blockchain for secure, tamper-proof backend</li>
    <li><strong>Intelligent Recommendations:</strong> Hybrid algorithm combining collaborative and content-based filtering</li>
    <li><strong>Seamless Playback:</strong> Hybrid audio player supporting multiple streaming sources</li>
    <li><strong>User-Centric Design:</strong> Intuitive interface with comprehensive music management features</li>
    <li><strong>Privacy-Preserving Authentication:</strong> Internet Identity integration for secure, anonymous login</li>
    <li><strong>Legal Compliance:</strong> Proper use of official APIs and respect for copyright</li>
  </ul>
  
  <h2>10.2 Technical Strengths</h2>
  <ul>
    <li>Modern React architecture with TypeScript for type safety</li>
    <li>Responsive design adapting to all device sizes</li>
    <li>Efficient state management with React Query</li>
    <li>Accessible UI components meeting WCAG standards</li>
    <li>Scalable backend on Internet Computer blockchain</li>
    <li>Comprehensive error handling and user feedback</li>
  </ul>
  
  <h2>10.3 Future Enhancements</h2>
  <p>Potential improvements and feature additions:</p>
  
  <h3>AI-Powered Features</h3>
  <ul>
    <li><strong>Mood Detection:</strong> Analyze user mood and suggest appropriate music</li>
    <li><strong>Smart Playlists:</strong> Auto-generate playlists based on context and preferences</li>
    <li><strong>Voice Commands:</strong> Voice-controlled playback and search</li>
  </ul>
  
  <h3>Social Features</h3>
  <ul>
    <li><strong>User Following:</strong> Follow other users and see their activity</li>
    <li><strong>Collaborative Playlists:</strong> Multiple users editing shared playlists</li>
    <li><strong>Social Sharing:</strong> Share songs and playlists on social media</li>
    <li><strong>Comments and Discussions:</strong> Community engagement around music</li>
  </ul>
  
  <h3>Advanced Music Features</h3>
  <ul>
    <li><strong>Lyrics Display:</strong> Synchronized lyrics during playback</li>
    <li><strong>Audio Equalizer:</strong> Customizable sound profiles</li>
    <li><strong>Crossfade:</strong> Smooth transitions between tracks</li>
    <li><strong>Offline Mode:</strong> Download songs for offline listening</li>
  </ul>
  
  <h3>Analytics and Insights</h3>
  <ul>
    <li><strong>Listening Statistics:</strong> Detailed analytics on listening habits</li>
    <li><strong>Year in Review:</strong> Annual summary of music preferences</li>
    <li><strong>Artist Discovery:</strong> Track new artist discoveries</li>
    <li><strong>Genre Exploration:</strong> Visualize genre diversity</li>
  </ul>
  
  <h2>10.4 Scalability Considerations</h2>
  <p>As the platform grows, several scalability measures can be implemented:</p>
  <ul>
    <li><strong>Canister Sharding:</strong> Distribute data across multiple canisters</li>
    <li><strong>Caching Layers:</strong> Implement additional caching for frequently accessed data</li>
    <li><strong>Load Balancing:</strong> Distribute requests across multiple backend instances</li>
    <li><strong>Database Optimization:</strong> Implement indexing and query optimization</li>
  </ul>
  
  <h2>10.5 Final Thoughts</h2>
  <p>Music Beats represents a successful integration of modern web technologies, blockchain infrastructure, and intelligent algorithms to create a compelling music streaming experience. The platform's foundation on the Internet Computer provides unique advantages in terms of security, decentralization, and user privacy, while the hybrid recommendation system ensures users discover music they love.</p>
  
  <p>The application demonstrates the potential of decentralized applications (dApps) in the entertainment space, offering a glimpse into the future of music streaming where users have greater control over their data and experience.</p>
  
  <h2>10.6 Acknowledgments</h2>
  <p>This project was built using:</p>
  <ul>
    <li><strong>Caffeine.ai:</strong> AI-powered development platform</li>
    <li><strong>Internet Computer:</strong> Blockchain infrastructure</li>
    <li><strong>DFINITY Foundation:</strong> Internet Computer development tools</li>
    <li><strong>Open Source Community:</strong> React, TypeScript, and numerous libraries</li>
  </ul>
</div>

<!-- Footer -->
<div style="margin-top: 40pt; padding-top: 20pt; border-top: 2pt solid #5B21B6; text-align: center;">
  <p style="font-size: 10pt; color: #6B7280;">
    © 2025 Music Beats. Built with love using <a href="https://caffeine.ai" style="color: #5B21B6; text-decoration: none;">caffeine.ai</a>
  </p>
  <p style="font-size: 9pt; color: #9CA3AF; margin-top: 10pt;">
    This document was generated on ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
  </p>
</div>

</body>
</html>
      `;

      // Create blob and download
      const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'Music_Beats_Project_Documentation.html';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success('Documentation generated successfully!', {
        description: 'The HTML document can be opened in Microsoft Word or any web browser.',
      });
    } catch (error) {
      console.error('Error generating documentation:', error);
      toast.error('Failed to generate documentation', {
        description: 'Please try again or contact support.',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Button
      onClick={generateDocumentation}
      disabled={isGenerating}
      className="gap-2"
      size="lg"
    >
      {isGenerating ? (
        <>
          <div className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
          Generating...
        </>
      ) : (
        <>
          <FileText className="h-5 w-5" />
          Generate Documentation
          <Download className="h-4 w-4 ml-1" />
        </>
      )}
    </Button>
  );
}
