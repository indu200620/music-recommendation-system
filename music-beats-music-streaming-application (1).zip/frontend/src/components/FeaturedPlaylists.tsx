import { useGetPublicPlaylists } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Music, Play } from 'lucide-react';
import { useMusicPlayer } from '../contexts/MusicPlayerContext';

export default function FeaturedPlaylists() {
  const { data: playlists, isLoading } = useGetPublicPlaylists();
  const { playSong } = useMusicPlayer();

  if (isLoading) {
    return (
      <section className="container px-4">
        <h2 className="text-2xl font-bold mb-6">Featured Telugu Playlists</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="shimmer h-64" />
          ))}
        </div>
      </section>
    );
  }

  if (!playlists || playlists.length === 0) {
    return (
      <section className="container px-4">
        <h2 className="text-2xl font-bold mb-6">Featured Telugu Playlists</h2>
        <Card className="p-12 text-center">
          <Music className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">No public playlists available yet. Create your first Telugu playlist!</p>
        </Card>
      </section>
    );
  }

  return (
    <section className="container px-4">
      <h2 className="text-2xl font-bold mb-6">Featured Telugu Playlists</h2>
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex gap-4 pb-4">
          {playlists.map((playlist) => (
            <Card key={playlist.id} className="w-64 flex-shrink-0 hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="aspect-square rounded-md bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center mb-4">
                  <Music className="h-16 w-16 text-primary" />
                </div>
                <CardTitle className="truncate">{playlist.name}</CardTitle>
                <CardDescription className="line-clamp-2">{playlist.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{playlist.songs.length} songs</span>
                  <Button
                    size="icon"
                    className="rounded-full"
                    onClick={() => playlist.songs.length > 0 && playSong(playlist.songs[0], playlist.songs)}
                    disabled={playlist.songs.length === 0}
                  >
                    <Play className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </section>
  );
}
