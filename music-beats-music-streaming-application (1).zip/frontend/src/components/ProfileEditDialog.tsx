import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useSaveCallerUserProfile } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import type { UserProfile } from '../backend';
import { Loader2 } from 'lucide-react';

interface ProfileEditDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userProfile: UserProfile;
}

export default function ProfileEditDialog({ open, onOpenChange, userProfile }: ProfileEditDialogProps) {
  const [username, setUsername] = useState(userProfile.username);
  const [bio, setBio] = useState(userProfile.bio);
  const { identity } = useInternetIdentity();
  const saveProfile = useSaveCallerUserProfile();

  useEffect(() => {
    if (open) {
      setUsername(userProfile.username);
      setBio(userProfile.bio);
    }
  }, [open, userProfile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identity || !username.trim()) return;

    const updatedProfile: UserProfile = {
      userId: identity.getPrincipal(),
      username: username.trim(),
      bio: bio.trim(),
      favoriteGenres: userProfile.favoriteGenres,
      favoriteArtists: userProfile.favoriteArtists,
      profileImage: userProfile.profileImage,
    };

    await saveProfile.mutateAsync(updatedProfile);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Profile</DialogTitle>
          <DialogDescription>Update your profile information</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex justify-center">
            <Avatar className="h-24 w-24">
              <AvatarImage
                src={userProfile.profileImage?.getDirectURL() || '/assets/generated/default-avatar.dim_150x150.png'}
                alt={userProfile.username}
              />
              <AvatarFallback className="text-2xl">{username.charAt(0).toUpperCase()}</AvatarFallback>
            </Avatar>
          </div>
          <div className="space-y-2">
            <Label htmlFor="username">Username *</Label>
            <Input id="username" placeholder="Enter your username" value={username} onChange={(e) => setUsername(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            <Textarea id="bio" placeholder="Tell us about your music taste..." value={bio} onChange={(e) => setBio(e.target.value)} rows={3} />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saveProfile.isPending}>
              Cancel
            </Button>
            <Button type="submit" disabled={saveProfile.isPending || !username.trim()}>
              {saveProfile.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Changes'
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
