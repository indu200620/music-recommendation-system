import { useInternetIdentity } from './hooks/useInternetIdentity';
import { useGetCallerUserProfile } from './hooks/useQueries';
import { ThemeProvider } from 'next-themes';
import { Toaster } from '@/components/ui/sonner';
import Header from './components/Header';
import Footer from './components/Footer';
import ProfileSetupModal from './components/ProfileSetupModal';
import HomePage from './pages/HomePage';
import AudioPlayer from './components/AudioPlayer';
import { MusicPlayerProvider } from './contexts/MusicPlayerContext';

export default function App() {
  const { identity, loginStatus } = useInternetIdentity();
  const { data: userProfile, isLoading: profileLoading, isFetched } = useGetCallerUserProfile();

  const isAuthenticated = !!identity;
  const showProfileSetup = isAuthenticated && !profileLoading && isFetched && userProfile === null;

  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
      <MusicPlayerProvider>
        <div className="flex flex-col min-h-screen">
          <Header />
          <main className="flex-1 pb-24">
            {loginStatus === 'initializing' ? (
              <div className="flex items-center justify-center h-[calc(100vh-200px)]">
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
                  <p className="text-muted-foreground">Loading...</p>
                </div>
              </div>
            ) : (
              <HomePage />
            )}
          </main>
          <Footer />
          <AudioPlayer />
          {showProfileSetup && <ProfileSetupModal />}
          <Toaster />
        </div>
      </MusicPlayerProvider>
    </ThemeProvider>
  );
}
