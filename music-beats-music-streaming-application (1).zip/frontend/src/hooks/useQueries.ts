import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { UserProfile, Playlist, YTMusicSong, SongRating, ListeningHistoryEntry, Genre } from '../backend';
import { Principal } from '@dfinity/principal';
import { toast } from 'sonner';

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
      toast.success('Profile saved successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to save profile: ${error.message}`);
    },
  });
}

export function useGetAllPublicProfiles() {
  const { actor, isFetching } = useActor();

  return useQuery<UserProfile[]>({
    queryKey: ['publicProfiles'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllPublicProfiles();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetUserPlaylists(userId?: Principal) {
  const { actor, isFetching } = useActor();

  return useQuery<Playlist[]>({
    queryKey: ['userPlaylists', userId?.toString()],
    queryFn: async () => {
      if (!actor || !userId) return [];
      return actor.getUserPlaylists(userId);
    },
    enabled: !!actor && !isFetching && !!userId,
  });
}

export function useGetPublicPlaylists() {
  const { actor, isFetching } = useActor();

  return useQuery<Playlist[]>({
    queryKey: ['publicPlaylists'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getPublicPlaylists();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useCreatePlaylist() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ name, description, isPublic }: { name: string; description: string; isPublic: boolean }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.createPlaylist(name, description, isPublic);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userPlaylists'] });
      queryClient.invalidateQueries({ queryKey: ['publicPlaylists'] });
      toast.success('Playlist created successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to create playlist: ${error.message}`);
    },
  });
}

export function useAddSongsToPlaylist() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ playlistId, songs }: { playlistId: string; songs: YTMusicSong[] }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addSongsToPlaylist(playlistId, songs);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userPlaylists'] });
      queryClient.invalidateQueries({ queryKey: ['publicPlaylists'] });
      toast.success('Song added to playlist');
    },
    onError: (error: Error) => {
      toast.error(`Failed to add song: ${error.message}`);
    },
  });
}

export function useDeletePlaylist() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (playlistId: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.deletePlaylist(playlistId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userPlaylists'] });
      queryClient.invalidateQueries({ queryKey: ['publicPlaylists'] });
      toast.success('Playlist deleted successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to delete playlist: ${error.message}`);
    },
  });
}

export function useUpdatePlaylist() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      playlistId,
      name,
      description,
      isPublic,
    }: {
      playlistId: string;
      name: string;
      description: string;
      isPublic: boolean;
    }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.updatePlaylist(playlistId, name, description, isPublic);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userPlaylists'] });
      queryClient.invalidateQueries({ queryKey: ['publicPlaylists'] });
      toast.success('Playlist updated successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to update playlist: ${error.message}`);
    },
  });
}

export function useRemoveSongFromPlaylist() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ playlistId, songId }: { playlistId: string; songId: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.removeSongFromPlaylist(playlistId, songId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userPlaylists'] });
      queryClient.invalidateQueries({ queryKey: ['publicPlaylists'] });
      toast.success('Song removed from playlist');
    },
    onError: (error: Error) => {
      toast.error(`Failed to remove song: ${error.message}`);
    },
  });
}

export function useRateSong() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ songId, rating }: { songId: string; rating: number }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.rateSong(songId, BigInt(rating));
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['songRatings', variables.songId] });
      queryClient.invalidateQueries({ queryKey: ['userRatings'] });
      toast.success('Rating submitted');
    },
    onError: (error: Error) => {
      toast.error(`Failed to rate song: ${error.message}`);
    },
  });
}

export function useGetSongRatings(songId: string) {
  const { actor, isFetching } = useActor();

  return useQuery<SongRating[]>({
    queryKey: ['songRatings', songId],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getSongRatings(songId);
    },
    enabled: !!actor && !isFetching && !!songId,
  });
}

export function useGetUserRatings() {
  const { actor, isFetching } = useActor();

  return useQuery<SongRating[]>({
    queryKey: ['userRatings'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getUserRatings();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAddToListeningHistory() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (songId: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addToListeningHistory(songId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['listeningHistory'] });
    },
    onError: (error: Error) => {
      console.error('Failed to add to listening history:', error);
    },
  });
}

export function useGetListeningHistory() {
  const { actor, isFetching } = useActor();

  return useQuery<ListeningHistoryEntry[]>({
    queryKey: ['listeningHistory'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getListeningHistory();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSearchSongs(query: string) {
  const { actor, isFetching } = useActor();

  return useQuery<YTMusicSong[]>({
    queryKey: ['searchSongs', query],
    queryFn: async () => {
      if (!actor || !query) return [];

      try {
        const response = await actor.searchSongs(query);
        // Backend returns raw JSON string, parse it
        const data = JSON.parse(response);

        if (data.items && Array.isArray(data.items)) {
          return data.items.map((item: any) => ({
            id: item.id || item.videoId || item.youtubeId || '',
            title: item.title || item.name || 'Unknown Title',
            artist: item.artist || item.artists?.[0]?.name || 'Unknown Artist',
            album: item.album || item.albumName || 'Unknown Album',
            genre: item.genre || 'Music',
            duration: BigInt(item.duration || item.lengthSeconds || 0),
            youtubeId: item.videoId || item.youtubeId || item.id || '',
            coverImage:
              item.thumbnail || item.thumbnails?.[0]?.url || item.coverImage || '/assets/generated/music-note-icon-transparent.dim_64x64.png',
            audioPreviewUrl: item.audioPreviewUrl || item.preview_url || '',
          }));
        }

        return [];
      } catch (error) {
        console.error('Error searching songs:', error);
        return [];
      }
    },
    enabled: !!actor && !isFetching && query.length > 0,
  });
}

export function useGetRecommendedSongs() {
  const { actor, isFetching } = useActor();

  return useQuery<YTMusicSong[]>({
    queryKey: ['recommendedSongs'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getRecommendedSongs();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetAllGenres() {
  const { actor, isFetching } = useActor();

  return useQuery<Genre[]>({
    queryKey: ['allGenres'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllGenres();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetSongsByGenre(genre: string) {
  const { actor, isFetching } = useActor();

  return useQuery<YTMusicSong[]>({
    queryKey: ['songsByGenre', genre],
    queryFn: async () => {
      if (!actor || !genre) return [];

      try {
        const response = await actor.getSongsByGenre(genre);
        // Backend returns raw JSON string, parse it
        const data = JSON.parse(response);

        if (data.items && Array.isArray(data.items)) {
          return data.items.map((item: any) => ({
            id: item.id || item.videoId || item.youtubeId || '',
            title: item.title || item.name || 'Unknown Title',
            artist: item.artist || item.artists?.[0]?.name || 'Unknown Artist',
            album: item.album || item.albumName || 'Unknown Album',
            genre: item.genre || genre,
            duration: BigInt(item.duration || item.lengthSeconds || 0),
            youtubeId: item.videoId || item.youtubeId || item.id || '',
            coverImage:
              item.thumbnail || item.thumbnails?.[0]?.url || item.coverImage || '/assets/generated/music-note-icon-transparent.dim_64x64.png',
            audioPreviewUrl: item.audioPreviewUrl || item.preview_url || '',
          }));
        }

        return [];
      } catch (error) {
        console.error('Error fetching songs by genre:', error);
        return [];
      }
    },
    enabled: !!actor && !isFetching && genre.length > 0,
  });
}
