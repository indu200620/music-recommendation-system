import { createContext, useContext, useState, useRef, useEffect, ReactNode } from 'react';
import type { YTMusicSong } from '../backend';
import { toast } from 'sonner';

interface MusicPlayerContextType {
  currentSong: YTMusicSong | null;
  isPlaying: boolean;
  volume: number;
  currentTime: number;
  duration: number;
  playlist: YTMusicSong[];
  currentIndex: number;
  isRepeat: boolean;
  isShuffle: boolean;
  isLoading: boolean;
  error: string | null;
  playSong: (song: YTMusicSong, playlist?: YTMusicSong[]) => void;
  pauseSong: () => void;
  resumeSong: () => void;
  nextSong: () => void;
  previousSong: () => void;
  setVolume: (volume: number) => void;
  seekTo: (time: number) => void;
  toggleRepeat: () => void;
  toggleShuffle: () => void;
}

const MusicPlayerContext = createContext<MusicPlayerContextType | undefined>(undefined);

// Declare YouTube API types
declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
  }
}

export function MusicPlayerProvider({ children }: { children: ReactNode }) {
  const [currentSong, setCurrentSong] = useState<YTMusicSong | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolumeState] = useState(70);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playlist, setPlaylist] = useState<YTMusicSong[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isRepeat, setIsRepeat] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const playerRef = useRef<any>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playerContainerRef = useRef<HTMLDivElement | null>(null);
  const timeUpdateIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const autoSkipTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const ytApiReadyRef = useRef(false);
  const playerTypeRef = useRef<'youtube' | 'audio'>('youtube');

  // Load YouTube IFrame API
  useEffect(() => {
    if (!window.YT) {
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      const firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag);

      window.onYouTubeIframeAPIReady = () => {
        ytApiReadyRef.current = true;
      };
    } else {
      ytApiReadyRef.current = true;
    }

    // Create audio element
    audioRef.current = new Audio();
    audioRef.current.volume = volume / 100;

    // Audio event listeners
    audioRef.current.addEventListener('loadedmetadata', () => {
      if (audioRef.current) {
        setDuration(audioRef.current.duration);
        setIsLoading(false);
      }
    });

    audioRef.current.addEventListener('canplay', () => {
      setIsLoading(false);
    });

    audioRef.current.addEventListener('playing', () => {
      setIsPlaying(true);
      setIsLoading(false);
      setError(null);
    });

    audioRef.current.addEventListener('pause', () => {
      setIsPlaying(false);
    });

    audioRef.current.addEventListener('ended', () => {
      setIsPlaying(false);
      if (isRepeat) {
        audioRef.current?.play();
      } else {
        handleNextSong();
      }
    });

    audioRef.current.addEventListener('timeupdate', () => {
      if (audioRef.current) {
        setCurrentTime(audioRef.current.currentTime);
      }
    });

    audioRef.current.addEventListener('error', (e) => {
      console.error('Audio error:', e);
      setError('Failed to load audio');
      setIsLoading(false);
      setIsPlaying(false);
      toast.error('Failed to load audio, skipping to next song...');
      autoSkipTimeoutRef.current = setTimeout(() => {
        handleNextSong();
      }, 2000);
    });

    return () => {
      if (timeUpdateIntervalRef.current) {
        clearInterval(timeUpdateIntervalRef.current);
      }
      if (autoSkipTimeoutRef.current) {
        clearTimeout(autoSkipTimeoutRef.current);
      }
      if (playerRef.current) {
        try {
          playerRef.current.destroy();
        } catch (e) {
          console.error('Error destroying player:', e);
        }
      }
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
      }
    };
  }, []);

  // Update audio volume when volume state changes
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume / 100;
    }
  }, [volume]);

  // Start time update interval for YouTube player when playing
  useEffect(() => {
    if (isPlaying && playerTypeRef.current === 'youtube' && playerRef.current) {
      timeUpdateIntervalRef.current = setInterval(() => {
        try {
          if (playerRef.current && typeof playerRef.current.getCurrentTime === 'function') {
            const time = playerRef.current.getCurrentTime();
            setCurrentTime(time);
          }
        } catch (e) {
          console.error('Error getting current time:', e);
        }
      }, 100);
    } else {
      if (timeUpdateIntervalRef.current) {
        clearInterval(timeUpdateIntervalRef.current);
        timeUpdateIntervalRef.current = null;
      }
    }

    return () => {
      if (timeUpdateIntervalRef.current) {
        clearInterval(timeUpdateIntervalRef.current);
      }
    };
  }, [isPlaying]);

  const handleNextSong = () => {
    if (playlist.length === 0) return;

    let nextIndex: number;
    if (isShuffle) {
      do {
        nextIndex = Math.floor(Math.random() * playlist.length);
      } while (nextIndex === currentIndex && playlist.length > 1);
    } else {
      nextIndex = (currentIndex + 1) % playlist.length;
    }

    setCurrentIndex(nextIndex);
    playSong(playlist[nextIndex]);
  };

  const onPlayerReady = (event: any) => {
    setIsLoading(false);
    event.target.setVolume(volume);
    event.target.playVideo();
  };

  const onPlayerStateChange = (event: any) => {
    const state = event.data;

    if (state === 1) {
      // Playing
      setIsPlaying(true);
      setIsLoading(false);
      setError(null);

      try {
        const dur = event.target.getDuration();
        if (dur && dur > 0) {
          setDuration(dur);
        }
      } catch (e) {
        console.error('Error getting duration:', e);
      }

      if (autoSkipTimeoutRef.current) {
        clearTimeout(autoSkipTimeoutRef.current);
        autoSkipTimeoutRef.current = null;
      }
    } else if (state === 2) {
      // Paused
      setIsPlaying(false);
      setIsLoading(false);
    } else if (state === 0) {
      // Ended
      setIsPlaying(false);
      if (isRepeat) {
        event.target.seekTo(0);
        event.target.playVideo();
      } else {
        handleNextSong();
      }
    } else if (state === 3) {
      // Buffering
      setIsLoading(true);
    } else if (state === -1) {
      // Unstarted
      setIsLoading(true);
    }
  };

  const onPlayerError = (event: any) => {
    const errorCode = event.data;
    let errorMessage = 'Video unavailable';

    switch (errorCode) {
      case 2:
        errorMessage = 'Invalid video parameter';
        break;
      case 5:
        errorMessage = 'HTML5 player error';
        break;
      case 100:
        errorMessage = 'Video not found or private';
        break;
      case 101:
      case 150:
        errorMessage = 'Video cannot be embedded';
        break;
    }

    console.error('YouTube player error:', errorCode, errorMessage);
    setError(errorMessage);
    setIsPlaying(false);
    setIsLoading(false);

    toast.error(`${errorMessage}, skipping to next song...`);

    autoSkipTimeoutRef.current = setTimeout(() => {
      handleNextSong();
    }, 2000);
  };

  const createYouTubePlayer = (videoId: string) => {
    if (!playerContainerRef.current) {
      const container = document.createElement('div');
      container.id = 'youtube-player-container';
      container.style.position = 'fixed';
      container.style.top = '-9999px';
      container.style.left = '-9999px';
      container.style.width = '1px';
      container.style.height = '1px';
      document.body.appendChild(container);
      playerContainerRef.current = container;
    }

    if (playerRef.current) {
      try {
        playerRef.current.destroy();
      } catch (e) {
        console.error('Error destroying player:', e);
      }
    }

    const waitForYT = setInterval(() => {
      if (window.YT && window.YT.Player) {
        clearInterval(waitForYT);

        try {
          playerRef.current = new window.YT.Player('youtube-player-container', {
            height: '1',
            width: '1',
            videoId: videoId,
            playerVars: {
              autoplay: 1,
              controls: 0,
              disablekb: 1,
              fs: 0,
              modestbranding: 1,
              playsinline: 1,
              rel: 0,
              showinfo: 0,
              iv_load_policy: 3,
            },
            events: {
              onReady: onPlayerReady,
              onStateChange: onPlayerStateChange,
              onError: onPlayerError,
            },
          });
        } catch (e) {
          console.error('Error creating YouTube player:', e);
          setError('Failed to create player');
          setIsLoading(false);
        }
      }
    }, 100);

    setTimeout(() => {
      clearInterval(waitForYT);
      if (!playerRef.current) {
        setError('Failed to load YouTube player');
        setIsLoading(false);
      }
    }, 10000);
  };

  const playSong = (song: YTMusicSong, newPlaylist?: YTMusicSong[]) => {
    setError(null);
    setCurrentSong(song);
    setCurrentTime(0);
    setDuration(0);

    if (autoSkipTimeoutRef.current) {
      clearTimeout(autoSkipTimeoutRef.current);
      autoSkipTimeoutRef.current = null;
    }

    if (newPlaylist) {
      setPlaylist(newPlaylist);
      const index = newPlaylist.findIndex((s) => s.id === song.id);
      setCurrentIndex(index >= 0 ? index : 0);
    }

    setIsLoading(true);

    // Check if song has audio preview URL (Spotify or direct audio)
    if (song.audioPreviewUrl && song.audioPreviewUrl.trim() !== '') {
      // Use HTML5 Audio for direct audio URLs
      playerTypeRef.current = 'audio';

      // Stop YouTube player if active
      if (playerRef.current && typeof playerRef.current.pauseVideo === 'function') {
        try {
          playerRef.current.pauseVideo();
        } catch (e) {
          console.error('Error pausing YouTube player:', e);
        }
      }

      // Play audio
      if (audioRef.current) {
        audioRef.current.src = song.audioPreviewUrl;
        audioRef.current.load();
        audioRef.current.play().catch((e) => {
          console.error('Error playing audio:', e);
          setError('Failed to play audio');
          setIsLoading(false);
        });
      }
    } else if (song.youtubeId && song.youtubeId.trim() !== '') {
      // Use YouTube player for YouTube videos
      playerTypeRef.current = 'youtube';

      // Pause HTML5 audio if active
      if (audioRef.current) {
        audioRef.current.pause();
      }

      if (playerRef.current && typeof playerRef.current.loadVideoById === 'function') {
        try {
          playerRef.current.loadVideoById(song.youtubeId);
          playerRef.current.setVolume(volume);
        } catch (e) {
          console.error('Error loading video:', e);
          createYouTubePlayer(song.youtubeId);
        }
      } else {
        createYouTubePlayer(song.youtubeId);
      }
    } else {
      setError('No playable source available');
      toast.error('No playable source available, skipping...');
      autoSkipTimeoutRef.current = setTimeout(() => {
        handleNextSong();
      }, 2000);
    }
  };

  const pauseSong = () => {
    if (playerTypeRef.current === 'youtube') {
      if (playerRef.current && typeof playerRef.current.pauseVideo === 'function') {
        try {
          playerRef.current.pauseVideo();
          setIsPlaying(false);
        } catch (e) {
          console.error('Error pausing video:', e);
        }
      }
    } else {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    }
  };

  const resumeSong = () => {
    if (playerTypeRef.current === 'youtube') {
      if (playerRef.current && typeof playerRef.current.playVideo === 'function') {
        try {
          playerRef.current.playVideo();
        } catch (e) {
          console.error('Error resuming video:', e);
          setError('Failed to resume playback');
        }
      }
    } else {
      if (audioRef.current) {
        audioRef.current.play().catch((e) => {
          console.error('Error resuming audio:', e);
          setError('Failed to resume playback');
        });
      }
    }
  };

  const nextSong = () => {
    handleNextSong();
  };

  const previousSong = () => {
    if (playlist.length === 0) return;

    if (currentTime > 3) {
      seekTo(0);
      return;
    }

    const prevIndex = currentIndex === 0 ? playlist.length - 1 : currentIndex - 1;
    setCurrentIndex(prevIndex);
    playSong(playlist[prevIndex]);
  };

  const setVolume = (newVolume: number) => {
    const clampedVolume = Math.max(0, Math.min(100, newVolume));
    setVolumeState(clampedVolume);

    if (playerTypeRef.current === 'youtube') {
      if (playerRef.current && typeof playerRef.current.setVolume === 'function') {
        try {
          playerRef.current.setVolume(clampedVolume);
        } catch (e) {
          console.error('Error setting volume:', e);
        }
      }
    } else {
      if (audioRef.current) {
        audioRef.current.volume = clampedVolume / 100;
      }
    }
  };

  const seekTo = (time: number) => {
    if (playerTypeRef.current === 'youtube') {
      if (playerRef.current && typeof playerRef.current.seekTo === 'function') {
        try {
          const clampedTime = Math.max(0, Math.min(time, duration));
          playerRef.current.seekTo(clampedTime, true);
          setCurrentTime(clampedTime);
        } catch (e) {
          console.error('Error seeking:', e);
        }
      }
    } else {
      if (audioRef.current) {
        const clampedTime = Math.max(0, Math.min(time, duration));
        audioRef.current.currentTime = clampedTime;
        setCurrentTime(clampedTime);
      }
    }
  };

  const toggleRepeat = () => {
    setIsRepeat(!isRepeat);
  };

  const toggleShuffle = () => {
    setIsShuffle(!isShuffle);
  };

  return (
    <MusicPlayerContext.Provider
      value={{
        currentSong,
        isPlaying,
        volume,
        currentTime,
        duration,
        playlist,
        currentIndex,
        isRepeat,
        isShuffle,
        isLoading,
        error,
        playSong,
        pauseSong,
        resumeSong,
        nextSong,
        previousSong,
        setVolume,
        seekTo,
        toggleRepeat,
        toggleShuffle,
      }}
    >
      {children}
    </MusicPlayerContext.Provider>
  );
}

export function useMusicPlayer() {
  const context = useContext(MusicPlayerContext);
  if (!context) {
    throw new Error('useMusicPlayer must be used within MusicPlayerProvider');
  }
  return context;
}
