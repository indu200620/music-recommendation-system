import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useGetCallerUserProfile } from '../hooks/useQueries';
import HeroSection from '../components/HeroSection';
import RecommendedSongs from '../components/RecommendedSongs';
import FeaturedPlaylists from '../components/FeaturedPlaylists';
import RecentlyPlayed from '../components/RecentlyPlayed';
import GenerateDocumentationButton from '../components/GenerateDocumentationButton';
import GenreSelection from '../components/GenreSelection';
import NowPlayingGenre from '../components/NowPlayingGenre';
import { Button } from '@/components/ui/button';
import { Music, FileText } from 'lucide-react';
import { useState } from 'react';
import LoginModal from '../components/LoginModal';
import type { YTMusicSong } from '../backend';

export default function HomePage() {
  const { identity } = useInternetIdentity();
  const { data: userProfile } = useGetCallerUserProfile();
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [genreSongs, setGenreSongs] = useState<YTMusicSong[]>([]);

  const isAuthenticated = !!identity;

  const handleGenreSelect = (genre: string, songs: YTMusicSong[]) => {
    setSelectedGenre(genre);
    setGenreSongs(songs);
  };

  return (
    <div className="min-h-screen">
      <section className="py-8 bg-gradient-to-br from-primary/5 via-secondary/5 to-primary/5">
        <div className="container px-4">
          <div className="mb-6">
            <h2 className="text-2xl font-bold mb-2">Browse by Genre</h2>
            <p className="text-muted-foreground">Explore music across different styles and languages</p>
          </div>
          <GenreSelection onGenreSelect={handleGenreSelect} />
        </div>
      </section>

      {selectedGenre && genreSongs.length > 0 && (
        <NowPlayingGenre genreName={selectedGenre} songs={genreSongs} />
      )}

      <HeroSection />

      {!isAuthenticated && (
        <section className="py-16 bg-muted/30">
          <div className="container px-4 text-center">
            <div className="max-w-2xl mx-auto space-y-6">
              <Music className="h-16 w-16 mx-auto text-primary" />
              <h2 className="text-3xl font-bold">Start Your Musical Journey</h2>
              <p className="text-lg text-muted-foreground">
                Log in to discover personalized recommendations, create playlists, and track your listening history.
              </p>
              <Button size="lg" onClick={() => setShowLoginModal(true)} className="bg-primary hover:bg-primary/90">
                Get Started
              </Button>
            </div>
          </div>
        </section>
      )}

      {isAuthenticated && userProfile && (
        <section className="py-12 bg-background">
          <div className="container px-4">
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-2">Welcome back, {userProfile.username}!</h2>
              <p className="text-muted-foreground">Continue where you left off</p>
            </div>
            <RecentlyPlayed />
          </div>
        </section>
      )}

      <section className="py-12 bg-muted/20">
        <div className="container px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-bold mb-2">Recommended for You</h2>
              <p className="text-muted-foreground">Discover new music based on your taste</p>
            </div>
          </div>
          <RecommendedSongs />
        </div>
      </section>

      <section className="py-12 bg-background">
        <div className="container px-4">
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-2">Featured Playlists</h2>
            <p className="text-muted-foreground">Curated collections from our community</p>
          </div>
          <FeaturedPlaylists />
        </div>
      </section>

      <section className="py-16 bg-gradient-to-br from-primary/10 via-secondary/10 to-primary/10">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <FileText className="h-16 w-16 mx-auto text-primary" />
            <h2 className="text-3xl font-bold">Project Documentation</h2>
            <p className="text-lg text-muted-foreground">
              Download comprehensive documentation about the Music Beats platform, including system architecture, 
              features, implementation details, and technical specifications.
            </p>
            <GenerateDocumentationButton />
            <p className="text-sm text-muted-foreground">
              The generated HTML document can be opened in Microsoft Word, Google Docs, or any web browser.
            </p>
          </div>
        </div>
      </section>

      <LoginModal open={showLoginModal} onOpenChange={setShowLoginModal} />
    </div>
  );
}
