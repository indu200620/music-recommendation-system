import List "mo:core/List";
import Map "mo:core/Map";
import Text "mo:core/Text";
import Time "mo:core/Time";
import Runtime "mo:core/Runtime";
import Iter "mo:core/Iter";
import Array "mo:core/Array";
import Nat "mo:core/Nat";
import Order "mo:core/Order";
import Principal "mo:core/Principal";

import Storage "blob-storage/Storage";
import MixinAuthorization "authorization/MixinAuthorization";
import MixinStorage "blob-storage/Mixin";

import AccessControl "authorization/access-control";
import OutCall "http-outcalls/outcall";

actor {
  // Initialize access control state
  let accessControlState = AccessControl.initState();
  include MixinAuthorization(accessControlState);
  include MixinStorage();

  //-----------------
  // Type Definitions
  //-----------------

  public type UserProfile = {
    userId : Principal;
    username : Text;
    bio : Text;
    favoriteGenres : [Text];
    favoriteArtists : [Text];
    profileImage : ?Storage.ExternalBlob;
  };

  public type Playlist = {
    id : Text;
    owner : Principal;
    name : Text;
    description : Text;
    songs : [YTMusicSong];
    isPublic : Bool;
    sharedWith : [Principal];
  };

  public type SongRating = {
    userId : Principal;
    songId : Text;
    rating : Nat;
    timestamp : Time.Time;
  };

  public type ListeningHistoryEntry = {
    userId : Principal;
    songId : Text;
    timestamp : Time.Time;
  };

  module Playlist {
    public func compareByName(playlist1 : Playlist, playlist2 : Playlist) : Order.Order {
      Text.compare(playlist1.name, playlist2.name);
    };
  };

  module SongRating {
    public func compare(rating1 : SongRating, rating2 : SongRating) : Order.Order {
      Nat.compare(rating1.rating, rating2.rating);
    };
  };

  public type YTMusicApiResponse = {
    items : [YTMusicSong];
  };

  public type YTMusicSong = {
    id : Text;
    title : Text;
    artist : Text;
    album : Text;
    genre : Text;
    duration : Nat;
    youtubeId : Text;
    coverImage : Text;
    audioPreviewUrl : Text;
  };

  public type Genre = {
    name : Text;
    icon : Text;
    description : Text;
  };

  module GenresByName {
    public func compare(g : Genre, h : Genre) : Order.Order {
      Text.compare(g.name, h.name);
    };
  };

  //-----------------
  // Persistent Data
  //-----------------

  let userProfiles = Map.empty<Principal, UserProfile>();
  let playlists = Map.empty<Text, Playlist>();
  let songRatings = Map.empty<Text, List.List<SongRating>>();
  let listeningHistory = Map.empty<Principal, List.List<ListeningHistoryEntry>>();

  // Initialize genres with 10 entries
  let genres = Map.fromIter<Text, Genre>(
    [
      (
        "Pop",
        {
          name = "Pop";
          icon = "pop.svg";
          description = "Popular and catchy modern music";
        },
      ),
      (
        "Classical",
        {
          name = "Classical";
          icon = "classical.svg";
          description = "Classical pieces and orchestral music";
        },
      ),
      (
        "Jazz",
        {
          name = "Jazz";
          icon = "jazz.svg";
          description = "Smooth jazz and improvisational music";
        },
      ),
      (
        "Rock",
        {
          name = "Rock";
          icon = "rock.svg";
          description = "Rock music spanning various styles";
        },
      ),
      (
        "Hip-Hop",
        {
          name = "Hip-Hop";
          icon = "hip_hop.svg";
          description = "Hip-Hop and rap tracks";
        },
      ),
      (
        "English",
        {
          name = "English";
          icon = "english.svg";
          description = "Songs in English language";
        },
      ),
      (
        "Hindi",
        {
          name = "Hindi";
          icon = "hindi.svg";
          description = "Songs in Hindi language";
        },
      ),
      (
        "Folk",
        {
          name = "Folk";
          icon = "folk.svg";
          description = "Traditional and folk music";
        },
      ),
      (
        "Instrumental",
        {
          name = "Instrumental";
          icon = "instrumental.svg";
          description = "Instrumental music with no vocals";
        },
      ),
      (
        "Electronic",
        {
          name = "Electronic";
          icon = "electronic.svg";
          description = "Electronic and dance music";
        },
      ),
    ].values(),
  );

  //-----------------
  // User Profile Management
  //-----------------

  public query ({ caller }) func getCallerUserProfile() : async ?UserProfile {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view profiles");
    };
    userProfiles.get(caller);
  };

  public query ({ caller }) func getUserProfile(user : Principal) : async ?UserProfile {
    if (caller != user and not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Can only view your own profile or must be admin");
    };
    userProfiles.get(user);
  };

  public shared ({ caller }) func saveCallerUserProfile(profile : UserProfile) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can save profiles");
    };
    userProfiles.add(
      caller,
      {
        userId = caller;
        username = profile.username;
        bio = profile.bio;
        favoriteGenres = profile.favoriteGenres;
        favoriteArtists = profile.favoriteArtists;
        profileImage = profile.profileImage;
      },
    );
  };

  public query func getAllPublicProfiles() : async [UserProfile] {
    // Any user (including guests) can view public profiles - no authorization check needed
    userProfiles.values().toArray();
  };

  //----------------------
  // Playlist Management
  //----------------------

  public shared ({ caller }) func createPlaylist(name : Text, description : Text, isPublic : Bool) : async Text {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can create playlists");
    };
    let playlistId = name.concat(Time.now().toText());
    let newPlaylist : Playlist = {
      id = playlistId;
      owner = caller;
      name;
      description;
      songs = [];
      isPublic;
      sharedWith = [];
    };

    playlists.add(playlistId, newPlaylist);
    playlistId;
  };

  public shared ({ caller }) func addSongsToPlaylist(playlistId : Text, songs : [YTMusicSong]) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can modify playlists");
    };
    switch (playlists.get(playlistId)) {
      case (null) { Runtime.trap("Playlist not found") };
      case (?playlist) {
        if (playlist.owner != caller) {
          Runtime.trap("Not authorized to modify this playlist");
        };
        let updatedSongs = playlist.songs.concat(songs);
        let updatedPlaylist = {
          playlist with
          songs = updatedSongs;
        };
        playlists.add(playlistId, updatedPlaylist);
      };
    };
  };

  public shared ({ caller }) func sharePlaylistWithUser(playlistId : Text, user : Principal) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can share playlists");
    };
    switch (playlists.get(playlistId)) {
      case (null) { Runtime.trap("Playlist not found") };
      case (?playlist) {
        if (playlist.owner != caller) {
          Runtime.trap("Not authorized to share this playlist");
        };
        let updatedSharedWith = playlist.sharedWith.concat([user]);
        let updatedPlaylist = {
          playlist with
          sharedWith = updatedSharedWith;
        };
        playlists.add(playlistId, updatedPlaylist);
      };
    };
  };

  public query ({ caller }) func getUserPlaylists(user : Principal) : async [Playlist] {
    // Users can view their own playlists, admins can view any user's playlists
    if (caller != user and not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Can only view your own playlists or must be admin");
    };
    playlists.values().toArray().filter(func(p) { p.owner == user });
  };

  public query func getPublicPlaylists() : async [Playlist] {
    // Any user (including guests) can view public playlists - no authorization check needed
    playlists.values().toArray().filter(func(p) { p.isPublic });
  };

  public query ({ caller }) func getSharedPlaylists() : async [Playlist] {
    // Only authenticated users can view playlists shared with them
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view shared playlists");
    };
    playlists.values().toArray().filter(func(p) {
      p.sharedWith.find<Principal>(func(u) { u == caller }) != null
    });
  };

  public shared ({ caller }) func deletePlaylist(playlistId : Text) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can delete playlists");
    };
    switch (playlists.get(playlistId)) {
      case (null) { Runtime.trap("Playlist not found") };
      case (?playlist) {
        if (playlist.owner != caller and not AccessControl.isAdmin(accessControlState, caller)) {
          Runtime.trap("Not authorized to delete this playlist");
        };
        playlists.remove(playlistId);
      };
    };
  };

  public shared ({ caller }) func updatePlaylist(playlistId : Text, name : Text, description : Text, isPublic : Bool) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can update playlists");
    };
    switch (playlists.get(playlistId)) {
      case (null) { Runtime.trap("Playlist not found") };
      case (?playlist) {
        if (playlist.owner != caller) {
          Runtime.trap("Not authorized to update this playlist");
        };
        let updatedPlaylist = {
          playlist with
          name = name;
          description = description;
          isPublic = isPublic;
        };
        playlists.add(playlistId, updatedPlaylist);
      };
    };
  };

  public shared ({ caller }) func removeSongFromPlaylist(playlistId : Text, songId : Text) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can modify playlists");
    };
    switch (playlists.get(playlistId)) {
      case (null) { Runtime.trap("Playlist not found") };
      case (?playlist) {
        if (playlist.owner != caller) {
          Runtime.trap("Not authorized to modify this playlist");
        };
        let updatedSongs = playlist.songs.filter(func(s) { s.id != songId });
        let updatedPlaylist = {
          playlist with
          songs = updatedSongs;
        };
        playlists.add(playlistId, updatedPlaylist);
      };
    };
  };

  //------------------
  // Song Ratings
  //------------------

  public shared ({ caller }) func rateSong(songId : Text, rating : Nat) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can rate songs");
    };
    if (rating < 1 or rating > 5) {
      Runtime.trap("Rating must be between 1 and 5 stars");
    };

    let newRating : SongRating = {
      userId = caller;
      songId;
      rating;
      timestamp = Time.now();
    };

    let existingRatings = switch (songRatings.get(songId)) {
      case (null) { List.empty<SongRating>() };
      case (?ratings) { ratings };
    };

    existingRatings.add(newRating);
    songRatings.add(songId, existingRatings);
  };

  public query func getSongRatings(songId : Text) : async [SongRating] {
    // Any user (including guests) can view song ratings - no authorization check needed
    switch (songRatings.get(songId)) {
      case (null) { [] };
      case (?ratings) { ratings.toArray().sort() };
    };
  };

  public query ({ caller }) func getUserRatings() : async [SongRating] {
    // Only authenticated users can view their own rating history
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view their rating history");
    };
    // Switch to flatten manually.
    let allRatings = songRatings.values().toArray();
    let userRatings = List.empty<SongRating>();
    for (ratings in allRatings.values()) {
      for (rating in ratings.values()) {
        if (rating.userId == caller) {
          userRatings.add(rating);
        };
      };
    };
    userRatings.toArray();
  };

  //--------------------------
  // Listening History
  //--------------------------

  public shared ({ caller }) func addToListeningHistory(songId : Text) : async () {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can track listening history");
    };
    let newEntry : ListeningHistoryEntry = {
      userId = caller;
      songId;
      timestamp = Time.now();
    };

    let existingHistory = switch (listeningHistory.get(caller)) {
      case (null) { List.empty<ListeningHistoryEntry>() };
      case (?history) { history };
    };

    existingHistory.add(newEntry);
    listeningHistory.add(caller, existingHistory);
  };

  public query ({ caller }) func getListeningHistory() : async [ListeningHistoryEntry] {
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can view listening history");
    };
    switch (listeningHistory.get(caller)) {
      case (null) { [] };
      case (?history) { history.toArray() };
    };
  };

  //----------------------------------
  // Song Search (YouTube Music & Spotify APIs)
  //----------------------------------

  public query func transform(input : OutCall.TransformationInput) : async OutCall.TransformationOutput {
    // transform function must be public query without authorization to work with http outcalls
    OutCall.transform(input);
  };

  public shared ({ caller }) func searchSongs(queryText : Text) : async Text {
    // Only authenticated users can search to prevent cycle abuse from anonymous callers
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can search for songs");
    };
    let apiEndpoint = "https://music-beats-api.com/search?query=" # queryText;
    await OutCall.httpGetRequest(apiEndpoint, [], transform);
  };

  //--------------------------
  // Genre & Artist Filtering
  //--------------------------

  public shared ({ caller }) func getSongsByGenre(genre : Text) : async Text {
    // Only authenticated users can browse to prevent cycle abuse from anonymous callers
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can browse songs by genre");
    };
    let apiEndpoint = "https://music-beats-api.com/genre?genre=" # genre;
    await OutCall.httpGetRequest(apiEndpoint, [], transform);
  };

  public shared ({ caller }) func getSongsByArtist(artist : Text) : async Text {
    // Only authenticated users can browse to prevent cycle abuse from anonymous callers
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can browse songs by artist");
    };
    let apiEndpoint = "https://music-beats-api.com/artist?artist=" # artist;
    await OutCall.httpGetRequest(apiEndpoint, [], transform);
  };

  public query func getAllGenres() : async [Genre] {
    // Any user (including guests) can view available genres - no authorization check needed
    genres.values().toArray().sort();
  };

  public query func getGenre(genre : Text) : async ?Genre {
    genres.get(genre);
  };

  public query func getAllArtists() : async [Text] {
    // Any user (including guests) can view available artists - no authorization check needed
    [];
  };

  //----------------------------------
  // Recommendations
  //----------------------------------

  public shared ({ caller }) func getRecommendedSongs() : async [YTMusicSong] {
    // Only authenticated users can get personalized recommendations
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can get personalized recommendations");
    };
    // Implementation would use listening history and ratings to generate recommendations
    [];
  };
};
