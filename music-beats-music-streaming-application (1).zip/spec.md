# Music Beats   Music Streaming Application

A music streaming application supporting both English and Hindi songs with YouTube Music API and Spotify API integration for real audio playback.

## Core Features

### Authentication
- User authentication system using Internet Identity with in-app modal or in-page login flow
- User registration and login functionality contained within the application interface
- Secure authentication without external window redirects
- Smooth transitions from login to user profile setup and music interaction

### User Profiles
- Profile creation with username, bio, favorite genres, and artists
- Profile avatar upload and storage using blob storage
- View and edit own profile with save functionality
- View other users' profiles
- Display user's created playlists and listening statistics on profile
- Profile editing interface with proper form validation and error handling

### Music Streaming
- Integration with YouTube Music API and Spotify API for accessing English and Hindi songs
- Real audio playback using track preview URLs and full audio streams from both APIs
- Song player with comprehensive audio controls: play, pause, skip forward/backward, repeat, shuffle
- Interactive progress bar with seek functionality showing accurate current time and total duration
- Real-time progress bar movement synced with audio playback events
- Automatic advancement to next song when current track ends
- Enhanced error handling for unavailable tracks with auto-skip to next playable song
- Cross-device and cross-browser compatibility for audio playback
- Accurate total duration display and current playback time tracking

### Genre Selection and Filtering
- Horizontally scrollable genre selection interface at the top of the homepage, above the hero section
- Display 8-10 popular genres: Pop, Classical, Jazz, Rock, Hip-Hop, English, Hindi, Folk, Instrumental, Electronic
- Each genre tile includes an icon or image, title text, and clickable functionality
- Clicking on any genre tile automatically triggers backend query to retrieve songs belonging to that genre using getSongsByGenre() API call
- Fetched songs are immediately passed to MusicPlayerContext to start playback beginning with the first song in the genre list
- Display selected genre's songs in a newly visible "Now Playing: [Genre Name]" section below the genre selection area
- Show real metadata (title, artist, album) for the currently playing genre's songs
- Maintain smooth integration with existing AudioPlayer for full play/pause, progress tracking, and volume control without page reloads
- Filter songs and playlists dynamically based on selected genre
- Update displayed recommendations and content based on genre selection
- Maintain violet-gold theme and design consistency

### Music Discovery and Search
- Search bar for finding English and Hindi songs, artists, and albums
- Search results fetched from YouTube Music API and Spotify API with real playable audio tracks
- Accurate track metadata including artist, album, cover art, and duration
- Immediate in-app playback of searched songs
- Home feed displaying recommended songs based on user listening history and preferences
- Featured playlists section on homepage
- Recently played songs section

### Listening History Tracking
- Track every song a user plays with songId and timestamp
- Display recent listening history on homepage
- Store comprehensive listening data for recommendation algorithm

### Recommendation System
- Intelligent recommendation algorithm using listening history and user ratings
- Collaborative filtering logic to suggest songs based on similar users' preferences
- Dynamic recommendation updates based on user behavior
- Personalized "Recommended for You" section on homepage

### Rating and Feedback System
- 1-5 star song rating system
- User ratings stored with timestamps to improve recommendation algorithm
- View personal rating history
- Ratings integrated into recommendation engine for better suggestions

### Playlist Management
- Create, edit, and delete personal playlists with English and Hindi songs
- Add/remove songs to/from playlists using API search results
- Share playlists with other users
- View shared playlists from other users
- Featured playlists display on homepage

### Documentation Generation
- Generate comprehensive project documentation in Word format (.docx)
- Document includes project overview, system architecture, feature explanations, implementation details, and technical specifications
- Structured sections with proper formatting, tables, and embedded images from application assets
- Downloadable documentation file for project presentation and reference
- Documentation covers frontend/backend architecture, API integrations, data flow diagrams, and deployment details

## Backend Data Storage
- User profiles (username, bio, favorite genres, artists, profile avatars via blob storage)
- User playlists and playlist contents with English and Hindi songs
- Song ratings and feedback from users with timestamps
- Comprehensive user listening history (songId, timestamp, user preferences)
- Playlist sharing permissions and access
- Songs catalog with complete metadata including titles, artist names, album information, genre, cover images, duration, and API track IDs for approximately 20 verified Hindi songs and existing English songs
- Genre categorization data for songs and filtering functionality
- Recommendation algorithm data and collaborative filtering matrices
- User preference patterns and similarity calculations for recommendation engine
- Generated documentation files and metadata for download functionality

## Design Requirements
- Clean, modern UI design
- Color theme: deep violet and gold
- Responsive design for desktop and mobile devices
- English language interface with English and Hindi music content
- Homepage layout featuring:
  - Genre Selection section at the top
  - "Now Playing: [Genre Name]" section below genre selection when a genre is selected
  - Featured Playlists
  - Recommended for You section
  - Recently Played section
  - Quick access to user playlists
- Documentation generation interface with download functionality

## Technical Integration
- YouTube Music API integration for song data and audio streaming
- Spotify API integration for additional song catalog and audio previews
- Real-time audio player functionality with proper event handling and stream management
- Advanced recommendation algorithm with collaborative filtering and user behavior analysis
- Robust audio player with buffering, error recovery, and unavailable track handling
- Song catalog populated with verified tracks having working playable audio streams
- Genre-based filtering and song retrieval functionality with automatic playback initiation
- In-app Internet Identity authentication flow without external redirects
- Blob storage integration for user profile avatars
- Comprehensive listening history tracking and analytics
- Profile management system with proper data persistence and retrieval
- Word document generation functionality with structured content, formatting, tables, and embedded images
- File download system for generated documentation
